import React, { useState } from 'react';
import {
  User,
  Mail,
  Lock,
  Smartphone,
  Calendar,
  MapPin,
  Heart,
  Baby,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Eye,
  EyeOff,
  Sparkles,
  Plus,
  Trash2,
  Info,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { requestOtpVerification, verifyOtpCode } from '../../services/authService';
import { BabyProfile } from '../../types';

interface SignupMultiStepProps {
  onBackToWelcome: () => void;
  onSwitchToLogin: () => void;
}

export const SignupMultiStep: React.FC<SignupMultiStepProps> = ({
  onBackToWelcome,
  onSwitchToLogin,
}) => {
  const { language, signup } = useApp();
  const isHi = language === 'hi';

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4 | 5>(1);
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Step 1: Account
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [otpNotice, setOtpNotice] = useState('');

  // Step 2: Personal & Health Profile
  const [dob, setDob] = useState('1998-05-15');
  const [country, setCountry] = useState('India');
  const [stateName, setStateName] = useState('Karnataka');
  const [city, setCity] = useState('Bengaluru');
  const [preferredLang, setPreferredLang] = useState(language);
  const [bloodGroup, setBloodGroup] = useState('B Positive (B+)');
  const [preExistingConditions, setPreExistingConditions] = useState<string[]>([]);
  const [conditionInput, setConditionInput] = useState('');
  const [allergies, setAllergies] = useState<string[]>([]);
  const [allergyInput, setAllergyInput] = useState('');
  const [currentMeds, setCurrentMeds] = useState<string[]>(['Folic Acid 5mg']);
  const [medInput, setMedInput] = useState('');

  // Step 3: Pregnancy Information
  const [situation, setSituation] = useState<'pregnant' | 'delivered' | 'planning' | 'other'>('pregnant');
  const [lmpDate, setLmpDate] = useState('2026-05-08');
  const [pregnancyType, setPregnancyType] = useState<'singleton' | 'twins'>('singleton');
  const [previousPregnancies, setPreviousPregnancies] = useState(0);

  // Step 4: Children
  const [hasExistingChildren, setHasExistingChildren] = useState<'yes' | 'no'>('no');
  const [addChildrenNow, setAddChildrenNow] = useState<'yes' | 'later'>('later');
  const [childrenList, setChildrenList] = useState<Array<Omit<BabyProfile, 'id'>>>([]);
  
  // Child form temporary fields
  const [childName, setChildName] = useState('');
  const [childDob, setChildDob] = useState('2026-01-10');
  const [childGender, setChildGender] = useState<'boy' | 'girl'>('boy');
  const [childWeight, setChildWeight] = useState(3.2);
  const [childLength, setChildLength] = useState(50.0);
  const [childPreterm, setChildPreterm] = useState(false);
  const [childGestWeeks, setChildGestWeeks] = useState(39);
  const [childFeeding, setChildFeeding] = useState<'exclusive_breastfeeding' | 'formula' | 'mixed_breast_and_formula' | 'solids_and_milk'>('exclusive_breastfeeding');

  // Request OTP for Step 1
  const handleSendOtp = () => {
    const id = email || phone;
    if (!id.trim()) {
      setErrorMsg(isHi ? 'कृपया पहले ईमेल या मोबाइल नंबर दर्ज करें' : 'Please enter your email or phone first');
      return;
    }
    setErrorMsg('');
    const res = requestOtpVerification(id);
    setOtpSent(true);
    setOtpNotice(res.message);
  };

  // Verify OTP for Step 1
  const handleVerifyOtp = () => {
    const id = email || phone;
    if (!otpCode.trim()) {
      setErrorMsg(isHi ? 'कृपया 6-अंकीय ओटीपी दर्ज करें' : 'Please enter the 6-digit verification code');
      return;
    }
    const valid = verifyOtpCode(id, otpCode);
    if (valid) {
      setOtpVerified(true);
      setErrorMsg('');
    } else {
      setErrorMsg(isHi ? 'अमान्य ओटीपी कोड। परीक्षण कोड: 123456' : 'Invalid OTP code. Use test code 123456');
    }
  };

  // Step 1 Validation & Proceed
  const handleNextStep1 = () => {
    setErrorMsg('');
    if (!fullName.trim()) {
      setErrorMsg(isHi ? 'कृपया अपना पूरा नाम दर्ज करें' : 'Please enter your full name');
      return;
    }
    if (!email.trim() && !phone.trim()) {
      setErrorMsg(isHi ? 'कृपया कम से कम एक ईमेल या मोबाइल नंबर दर्ज करें' : 'Please provide either an email or a mobile number');
      return;
    }
    if (password.length < 8) {
      setErrorMsg(isHi ? 'पासवर्ड में कम से कम 8 अक्षर होने चाहिए' : 'Password must be at least 8 characters long');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg(isHi ? 'पासवर्ड और पुष्टि पासवर्ड मेल नहीं खाते' : 'Passwords do not match');
      return;
    }
    if (!acceptedTerms) {
      setErrorMsg(isHi ? 'कृपया नियम और शर्तें स्वीकार करें' : 'Please accept the Terms of Service & Privacy Policy');
      return;
    }
    setCurrentStep(2);
  };

  // Step 4: Add child to list
  const handleAddChildToList = () => {
    if (!childName.trim()) return;
    const newChild: Omit<BabyProfile, 'id'> = {
      name: childName.trim(),
      gender: childGender,
      birthDate: childDob,
      birthTime: '10:00 AM',
      birthWeightKg: Number(childWeight),
      birthLengthCm: Number(childLength),
      birthHeadCircumferenceCm: 34.0,
      gestationalAgeWeeksAtBirth: childPreterm ? Number(childGestWeeks) : 39,
      isPremature: childPreterm,
      bloodGroup: 'B Positive (B+)',
      birthHistory: childPreterm ? `Preterm birth at ${childGestWeeks} weeks` : 'Full-term birth',
      medicalConditions: [],
      allergies: [],
      currentMedications: ['Vitamin D3 drops 400 IU daily'],
      feedingMethod: childFeeding,
      pediatricianName: 'Dr. Suresh Rao (MD Pediatrics)',
      pediatricianPhone: '+91 98222 33445',
      householdCircumstances: {
        dietaryPattern: 'vegetarian',
        drinkingWaterSource: 'Reverse Osmosis filtration',
        indoorSmokeExposure: false,
        smokingInHousehold: false,
      },
    };

    setChildrenList([...childrenList, newChild]);
    setChildName('');
    setChildPreterm(false);
  };

  // Final Step 5: Complete Registration
  const handleCompleteRegistration = async () => {
    setIsLoading(true);
    setErrorMsg('');
    try {
      const res = await signup({
        name: fullName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        password,
        preferredLanguage: preferredLang,
        city,
        state: stateName,
        country,
        bloodGroup,
        situation,
        lmpDate: situation === 'pregnant' ? lmpDate : undefined,
        children: childrenList,
        preExistingConditions,
        allergies,
        currentMedications: currentMeds,
      });

      if (!res.success) {
        setErrorMsg(res.error || 'Failed to complete registration');
      }
    } catch (e: any) {
      setErrorMsg(e?.message || 'Server error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FAF7F2] via-purple-50/40 to-[#FAF7F2] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full mx-auto space-y-6">
        {/* Navigation Bar */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => {
              if (currentStep > 1) setCurrentStep((currentStep - 1) as any);
              else onBackToWelcome();
            }}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-purple-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{currentStep > 1 ? (isHi ? 'पिछला चरण' : 'Previous Step') : (isHi ? 'वापस' : 'Back')}</span>
          </button>

          <span className="text-xs font-extrabold text-purple-800 bg-purple-100/80 px-3 py-1 rounded-full border border-purple-200">
            {isHi ? `चरण ${currentStep} / 5` : `Step ${currentStep} of 5`}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-500 h-full transition-all duration-300"
            style={{ width: `${(currentStep / 5) * 100}%` }}
          />
        </div>

        {/* Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-purple-100 shadow-xl space-y-6 relative overflow-hidden">
          {/* Top highlight bar */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-500" />

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* ========================================================================= */}
          {/* STEP 1: ACCOUNT DETAILS                                                   */}
          {/* ========================================================================= */}
          {currentStep === 1 && (
            <div className="space-y-5 text-xs">
              <div className="space-y-1">
                <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <User className="w-5 h-5 text-purple-600" />
                  <span>{isHi ? 'चरण 1: खाता विवरण' : 'Step 1: Account Details'}</span>
                </h3>
                <p className="text-slate-500 text-xs">
                  {isHi ? 'अपना नाम, संपर्क जानकारी और सुरक्षित पासवर्ड दर्ज करें।' : 'Set up your credentials for secure multi-device access.'}
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="font-extrabold text-slate-700 block mb-1">
                    {isHi ? 'पूरा नाम *' : 'Full Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    placeholder={isHi ? 'उदा. प्रिया शर्मा' : 'e.g. Priya Sharma'}
                    className="w-full px-3.5 py-2.5 border rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'ईमेल पता *' : 'Email Address *'}
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full px-3.5 py-2.5 border rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'मोबाइल नंबर *' : 'Mobile Number *'}
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      className="w-full px-3.5 py-2.5 border rounded-xl"
                    />
                  </div>
                </div>

                {/* OTP Verification Box */}
                <div className="p-3.5 bg-purple-50/70 border border-purple-200/80 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-purple-900 text-[11px] flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-purple-700" />
                      <span>{isHi ? 'ओटीपी सत्यापन' : 'OTP Verification'}</span>
                    </span>
                    {otpVerified ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-extrabold text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{isHi ? 'सत्यापित' : 'Verified'}</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={handleSendOtp}
                        className="text-purple-700 hover:text-purple-900 font-extrabold text-[11px] underline"
                      >
                        {otpSent ? (isHi ? 'पुनः भेजें' : 'Resend Code') : (isHi ? 'ओटीपी प्राप्त करें' : 'Send Verification OTP')}
                      </button>
                    )}
                  </div>

                  {otpSent && !otpVerified && (
                    <div className="space-y-2 pt-1">
                      {otpNotice && <p className="text-[10px] text-purple-800">{otpNotice}</p>}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={6}
                          value={otpCode}
                          onChange={e => setOtpCode(e.target.value)}
                          placeholder="123456"
                          className="flex-1 px-3 py-1.5 border rounded-lg text-center font-mono font-bold"
                        />
                        <button
                          type="button"
                          onClick={handleVerifyOtp}
                          className="px-3 py-1.5 bg-purple-700 text-white rounded-lg font-bold"
                        >
                          {isHi ? 'सत्यापित करें' : 'Verify'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Password Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'पासवर्ड (न्यूनतम 8 अक्षर) *' : 'Password (min 8 chars) *'}
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-3 pr-9 py-2.5 border rounded-xl"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'पासवर्ड की पुष्टि करें *' : 'Confirm Password *'}
                    </label>
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3.5 py-2.5 border rounded-xl"
                    />
                  </div>
                </div>

                {/* Terms & Consent */}
                <label className="flex items-start gap-2.5 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={acceptedTerms}
                    onChange={e => setAcceptedTerms(e.target.checked)}
                    className="mt-0.5 rounded text-purple-700"
                  />
                  <span className="text-[11px] text-slate-600 leading-relaxed">
                    {isHi
                      ? 'मैं मुमोरा के नियम और शर्तों और गोपनीयता नीति से सहमत हूँ, और अपने स्वास्थ्य डेटा के सुरक्षित प्रसंस्करण की सहमति देती हूँ।'
                      : 'I accept Mumora’s Terms of Service and Privacy Policy, and consent to the secure processing of my health data in compliance with DPDPA 2023.'}
                  </span>
                </label>
              </div>

              <div className="pt-3 flex justify-end">
                <button
                  type="button"
                  onClick={handleNextStep1}
                  className="px-6 py-3 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-extrabold text-xs flex items-center gap-1.5 shadow-sm"
                >
                  <span>{isHi ? 'अगला: व्यक्तिगत प्रोफाइल' : 'Continue to Profile'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* STEP 2: PERSONAL & HEALTH PROFILE                                         */}
          {/* ========================================================================= */}
          {currentStep === 2 && (
            <div className="space-y-5 text-xs">
              <div className="space-y-1">
                <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <Heart className="w-5 h-5 text-purple-600" />
                  <span>{isHi ? 'चरण 2: व्यक्तिगत और स्वास्थ्य प्रोफाइल' : 'Step 2: Personal & Health Profile'}</span>
                </h3>
                <p className="text-slate-500 text-xs">
                  {isHi ? 'यह जानकारी आपके क्लिनिकल चार्ट और आहार सुझावों को अनुकूलित करने में मदद करती है।' : 'Helps personalize clinical guidance, environmental alerts, and nutrition.'}
                </p>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'जन्म तिथि *' : 'Date of Birth *'}
                    </label>
                    <input
                      type="date"
                      value={dob}
                      onChange={e => setDob(e.target.value)}
                      className="w-full px-3 py-2 border rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'रक्त समूह' : 'Blood Group'}
                    </label>
                    <select
                      value={bloodGroup}
                      onChange={e => setBloodGroup(e.target.value)}
                      className="w-full px-3 py-2 border rounded-xl"
                    >
                      <option value="A Positive (A+)">A Positive (A+)</option>
                      <option value="A Negative (A-)">A Negative (A-)</option>
                      <option value="B Positive (B+)">B Positive (B+)</option>
                      <option value="B Negative (B-)">B Negative (B-)</option>
                      <option value="O Positive (O+)">O Positive (O+)</option>
                      <option value="O Negative (O-)">O Negative (O-)</option>
                      <option value="AB Positive (AB+)">AB Positive (AB+)</option>
                      <option value="AB Negative (AB-)">AB Negative (AB-)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'शहर *' : 'City *'}
                    </label>
                    <input
                      type="text"
                      value={city}
                      onChange={e => setCity(e.target.value)}
                      placeholder={isHi ? 'उदा. दिल्ली / जयपुर' : 'e.g. Bengaluru'}
                      className="w-full px-3 py-2 border rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'राज्य *' : 'State *'}
                    </label>
                    <input
                      type="text"
                      value={stateName}
                      onChange={e => setStateName(e.target.value)}
                      placeholder={isHi ? 'उदा. राजस्थान' : 'e.g. Karnataka'}
                      className="w-full px-3 py-2 border rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-extrabold text-slate-700 block mb-1">
                      {isHi ? 'देश *' : 'Country *'}
                    </label>
                    <input
                      type="text"
                      value={country}
                      onChange={e => setCountry(e.target.value)}
                      className="w-full px-3 py-2 border rounded-xl"
                    />
                  </div>
                </div>

                {/* Pre-existing Conditions */}
                <div>
                  <label className="font-extrabold text-slate-700 block mb-1">
                    {isHi ? 'मौजूदा स्वास्थ्य स्थितियां (वैकल्पिक)' : 'Known Medical Conditions (Optional)'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={conditionInput}
                      onChange={e => setConditionInput(e.target.value)}
                      placeholder={isHi ? 'उदा. थायराइड, मधुमेह, हल्का एनीमिया' : 'e.g. Thyroid, Gestational Diabetes, Mild Anemia'}
                      className="flex-1 px-3 py-2 border rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (conditionInput.trim()) {
                          setPreExistingConditions([...preExistingConditions, conditionInput.trim()]);
                          setConditionInput('');
                        }
                      }}
                      className="px-3 py-2 bg-purple-100 text-purple-900 rounded-xl font-bold"
                    >
                      {isHi ? 'जोड़ें' : 'Add'}
                    </button>
                  </div>
                  {preExistingConditions.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {preExistingConditions.map((c, i) => (
                        <span key={i} className="inline-flex items-center gap-1 px-2.5 py-1 bg-purple-50 text-purple-800 rounded-lg text-[11px] font-semibold">
                          <span>{c}</span>
                          <button
                            type="button"
                            onClick={() => setPreExistingConditions(preExistingConditions.filter((_, idx) => idx !== i))}
                            className="text-purple-400 hover:text-purple-900"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Allergies */}
                <div>
                  <label className="font-extrabold text-slate-700 block mb-1">
                    {isHi ? 'एलर्जी विवरण (वैकल्पिक)' : 'Known Allergies (Optional)'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={allergyInput}
                      onChange={e => setAllergyInput(e.target.value)}
                      placeholder={isHi ? 'उदा. पेनिसिलिन, मूंगफली' : 'e.g. Penicillin, Peanuts, Pollen'}
                      className="flex-1 px-3 py-2 border rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (allergyInput.trim()) {
                          setAllergies([...allergies, allergyInput.trim()]);
                          setAllergyInput('');
                        }
                      }}
                      className="px-3 py-2 bg-purple-100 text-purple-900 rounded-xl font-bold"
                    >
                      {isHi ? 'जोड़ें' : 'Add'}
                    </button>
                  </div>
                  {allergies.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {allergies.map((a, i) => (
                        <span key={i} className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 text-rose-800 rounded-lg text-[11px] font-semibold">
                          <span>{a}</span>
                          <button
                            type="button"
                            onClick={() => setAllergies(allergies.filter((_, idx) => idx !== i))}
                            className="text-rose-400 hover:text-rose-900"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-3 flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="px-4 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {isHi ? 'पिछला चरण' : 'Back'}
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="px-6 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-extrabold flex items-center gap-1.5"
                >
                  <span>{isHi ? 'आगे बढ़ें: गर्भावस्था विवरण' : 'Continue to Pregnancy Info'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* STEP 3: PREGNANCY INFORMATION                                             */}
          {/* ========================================================================= */}
          {currentStep === 3 && (
            <div className="space-y-5 text-xs">
              <div className="space-y-1">
                <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <Baby className="w-5 h-5 text-purple-600" />
                  <span>{isHi ? 'चरण 3: गर्भावस्था की स्थिति' : 'Step 3: Pregnancy Situation'}</span>
                </h3>
                <p className="text-slate-500 text-xs">
                  {isHi ? 'आपकी वर्तमान स्थिति क्या है?' : 'What best describes your current journey?'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {[
                  { id: 'pregnant', label: isHi ? 'वर्तमान में गर्भवती' : 'Currently Pregnant' },
                  { id: 'delivered', label: isHi ? 'शिशु का जन्म हो चुका है' : 'Already Delivered / New Mother' },
                  { id: 'planning', label: isHi ? 'गर्भावस्था की योजना' : 'Planning Pregnancy' },
                  { id: 'other', label: isHi ? 'अन्य स्थिति' : 'Other / Not Applicable' },
                ].map(opt => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setSituation(opt.id as any)}
                    className={`p-3.5 rounded-2xl border text-left font-bold transition-all flex items-center justify-between ${
                      situation === opt.id
                        ? 'border-purple-600 bg-purple-50/80 text-purple-950 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {situation === opt.id && <Check className="w-4 h-4 text-purple-700" />}
                  </button>
                ))}
              </div>

              {situation === 'pregnant' && (
                <div className="p-4 bg-purple-50/60 border border-purple-200/80 rounded-2xl space-y-3 mt-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-extrabold text-purple-950 block mb-1">
                        {isHi ? 'अंतिम मासिक धर्म की तारीख (LMP) *' : 'Last Menstrual Period (LMP Date) *'}
                      </label>
                      <input
                        type="date"
                        value={lmpDate}
                        onChange={e => setLmpDate(e.target.value)}
                        className="w-full px-3 py-2 bg-white border rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="font-extrabold text-purple-950 block mb-1">
                        {isHi ? 'गर्भावस्था का प्रकार' : 'Pregnancy Type'}
                      </label>
                      <select
                        value={pregnancyType}
                        onChange={e => setPregnancyType(e.target.value as any)}
                        className="w-full px-3 py-2 bg-white border rounded-xl"
                      >
                        <option value="singleton">{isHi ? 'एकल शिशु' : 'Singleton'}</option>
                        <option value="twins">{isHi ? 'जुड़वाँ / एकाधिक' : 'Multiple / Twins'}</option>
                      </select>
                    </div>
                  </div>

                  <div className="text-[11px] text-purple-800 flex items-center gap-1.5 pt-1">
                    <Info className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span>
                      {isHi
                        ? 'यह गणना केवल शैक्षिक अनुमान है और चिकित्सकीय परीक्षण का विकल्प नहीं है।'
                        : 'Calculations are educational estimates and never replace clinical ultrasound findings.'}
                    </span>
                  </div>
                </div>
              )}

              <div className="pt-3 flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="px-4 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {isHi ? 'पिछला चरण' : 'Back'}
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(4)}
                  className="px-6 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-extrabold flex items-center gap-1.5"
                >
                  <span>{isHi ? 'आगे बढ़ें: बच्चों का विवरण' : 'Continue to Children'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* STEP 4: FIRST BABY & ADDITIONAL CHILDREN                                  */}
          {/* ========================================================================= */}
          {currentStep === 4 && (
            <div className="space-y-5 text-xs">
              <div className="space-y-1">
                <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <Baby className="w-5 h-5 text-purple-600" />
                  <span>{isHi ? 'चरण 4: पहले से मौजूद बच्चे' : 'Step 4: Existing Children'}</span>
                </h3>
                <p className="text-slate-500 text-xs">
                  {isHi ? 'क्या आपका पहले से कोई बच्चा है?' : 'Do you already have one or more children?'}
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setHasExistingChildren('yes')}
                  className={`flex-1 py-3 rounded-2xl border font-bold text-center transition-all ${
                    hasExistingChildren === 'yes'
                      ? 'border-purple-600 bg-purple-50 text-purple-950 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  {isHi ? 'हाँ' : 'Yes'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setHasExistingChildren('no');
                    setChildrenList([]);
                  }}
                  className={`flex-1 py-3 rounded-2xl border font-bold text-center transition-all ${
                    hasExistingChildren === 'no'
                      ? 'border-purple-600 bg-purple-50 text-purple-950 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  {isHi ? 'नहीं' : 'No'}
                </button>
              </div>

              {hasExistingChildren === 'yes' && (
                <div className="p-4 bg-slate-50 border rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-slate-800">
                      {isHi ? `बच्चों की प्रोफाइल (${childrenList.length} जोड़ी गई)` : `Child Profiles (${childrenList.length} added)`}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {isHi ? 'आप अभी जोड़ सकते हैं या बाद में डैशबोर्ड से जोड़ सकते हैं।' : 'You can add now or skip and add later from dashboard.'}
                    </span>
                  </div>

                  {/* Registered children list */}
                  {childrenList.map((ch, idx) => (
                    <div key={idx} className="p-3 bg-white border rounded-xl flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="font-extrabold text-slate-900 block text-xs">
                          {ch.gender === 'boy' ? '👦' : '👧'} {ch.name}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {isHi ? 'जन्म तिथि:' : 'DOB:'} {ch.birthDate} · {isHi ? 'वजन:' : 'Birth:'} {ch.birthWeightKg}kg {ch.isPremature ? (isHi ? '(समय पूर्व)' : '(Preterm)') : ''}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setChildrenList(childrenList.filter((_, i) => i !== idx))}
                        className="text-rose-500 hover:text-rose-700 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}

                  {/* Form to add a child */}
                  <div className="p-3 bg-white border border-purple-200 rounded-xl space-y-3">
                    <span className="font-bold text-purple-950 block text-[11px]">
                      {isHi ? '+ बच्चे की जानकारी जोड़ें' : '+ Add Child Information'}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={childName}
                        onChange={e => setChildName(e.target.value)}
                        placeholder={isHi ? 'बच्चे का नाम (उदा. आरव)' : "Child's Name (e.g. Aarav)"}
                        className="px-3 py-1.5 border rounded-lg"
                      />
                      <input
                        type="date"
                        value={childDob}
                        onChange={e => setChildDob(e.target.value)}
                        className="px-3 py-1.5 border rounded-lg"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <select
                        value={childGender}
                        onChange={e => setChildGender(e.target.value as any)}
                        className="px-2 py-1.5 border rounded-lg"
                      >
                        <option value="boy">{isHi ? 'बालक' : 'Boy'}</option>
                        <option value="girl">{isHi ? 'बालिका' : 'Girl'}</option>
                      </select>
                      <input
                        type="number"
                        step="0.05"
                        value={childWeight}
                        onChange={e => setChildWeight(Number(e.target.value))}
                        placeholder={isHi ? 'वजन (किलो)' : 'Weight kg'}
                        className="px-2 py-1.5 border rounded-lg"
                      />
                      <input
                        type="number"
                        step="0.5"
                        value={childLength}
                        onChange={e => setChildLength(Number(e.target.value))}
                        placeholder={isHi ? 'लंबाई (सेमी)' : 'Length cm'}
                        className="px-2 py-1.5 border rounded-lg"
                      />
                    </div>

                    <label className="flex items-center gap-2 text-[11px] text-slate-700">
                      <input
                        type="checkbox"
                        checked={childPreterm}
                        onChange={e => setChildPreterm(e.target.checked)}
                      />
                      <span>{isHi ? 'समय पूर्व जन्म (< 37 सप्ताह)' : 'Born preterm (< 37 weeks)'}</span>
                    </label>

                    <button
                      type="button"
                      onClick={handleAddChildToList}
                      disabled={!childName.trim()}
                      className="w-full py-2 bg-purple-100 hover:bg-purple-200 text-purple-900 rounded-lg font-bold text-xs disabled:opacity-40"
                    >
                      {isHi ? '+ बच्चे को सूची में जोड़ें' : '+ Save Child to List'}
                    </button>
                  </div>
                </div>
              )}

              <div className="pt-3 flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="px-4 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {isHi ? 'पिछला चरण' : 'Back'}
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(5)}
                  className="px-6 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-extrabold flex items-center gap-1.5"
                >
                  <span>{isHi ? 'समीक्षा एवं पूर्ण करें' : 'Review & Finish'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* STEP 5: REVIEW & FINISH REGISTRATION                                      */}
          {/* ========================================================================= */}
          {currentStep === 5 && (
            <div className="space-y-5 text-xs">
              <div className="space-y-1">
                <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>{isHi ? 'चरण 5: समीक्षा एवं खाता पूर्ण करें' : 'Step 5: Review & Finish Registration'}</span>
                </h3>
                <p className="text-slate-500 text-xs">
                  {isHi ? 'कृपया अपने विवरण की समीक्षा करें। आप डैशबोर्ड से कभी भी जानकारी अपडेट कर सकते हैं।' : 'Verify your profile details. You can update any information anytime from the dashboard.'}
                </p>
              </div>

              {/* Review Card */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="font-extrabold text-slate-800 text-sm">{fullName}</span>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(1)}
                    className="text-[11px] text-purple-700 font-bold hover:underline"
                  >
                    {isHi ? 'संशोधन' : 'Edit Account'}
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-slate-600">
                  <div><strong>{isHi ? 'ईमेल:' : 'Email:'}</strong> {email || (isHi ? 'दर्ज नहीं किया' : 'Not provided')}</div>
                  <div><strong>{isHi ? 'मोबाइल:' : 'Phone:'}</strong> {phone || (isHi ? 'दर्ज नहीं किया' : 'Not provided')}</div>
                  <div><strong>{isHi ? 'शहर:' : 'City:'}</strong> {city}, {stateName}</div>
                  <div><strong>{isHi ? 'रक्त समूह:' : 'Blood Group:'}</strong> {bloodGroup}</div>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="font-extrabold text-slate-800 block">{isHi ? 'वर्तमान स्थिति:' : 'Journey Status:'}</span>
                    <span className="capitalize">
                      {situation === 'pregnant'
                        ? (isHi ? 'गर्भवती' : 'Pregnant')
                        : situation === 'delivered'
                        ? (isHi ? 'प्रसव हो चुका' : 'Delivered')
                        : situation === 'planning'
                        ? (isHi ? 'योजना' : 'Planning')
                        : (isHi ? 'अन्य' : 'Other')}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="text-[11px] text-purple-700 font-bold hover:underline"
                  >
                    {isHi ? 'संशोधन' : 'Edit'}
                  </button>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="font-extrabold text-slate-800 block">{isHi ? 'पंजीकृत बच्चे:' : 'Children Registered:'}</span>
                    <span>{childrenList.length > 0 ? (isHi ? `${childrenList.length} बच्चे` : `${childrenList.length} child(ren)`) : (isHi ? 'कोई नहीं (बाद में जोड़ेंगे)' : 'None (will add later)')}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(4)}
                    className="text-[11px] text-purple-700 font-bold hover:underline"
                  >
                    {isHi ? 'संशोधन' : 'Edit'}
                  </button>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-[11px] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{isHi ? 'आपकी प्रोफाइल सुरक्षित रूप से पृथक है और परिवार का डेटा एन्क्रिप्टेड है।' : 'Your profile is partitioned securely and isolated from all other family accounts.'}</span>
              </div>

              <div className="pt-3 flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(4)}
                  className="px-4 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {isHi ? 'पिछला चरण' : 'Back'}
                </button>
                <button
                  type="button"
                  disabled={isLoading}
                  onClick={handleCompleteRegistration}
                  className="px-6 py-3 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-800 hover:to-indigo-800 text-white rounded-xl font-extrabold text-sm flex items-center gap-2 shadow-md shadow-purple-900/10 disabled:opacity-50"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>{isHi ? 'पंजीकरण पूर्ण करें और डैशबोर्ड खोलें' : 'Complete Registration & Open Dashboard'}</span>
                      <Check className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
