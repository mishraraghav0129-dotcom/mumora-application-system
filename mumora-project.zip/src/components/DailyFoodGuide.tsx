import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  DietaryPreferenceType,
  LocalDishEvaluation,
  FoodAlternativeItem,
  GroceryItem,
} from '../types';
import {
  WHO_NUTRITION_REFERENCES,
  REGIONAL_FOOD_DATABASE,
  SAMPLE_FOOD_ALTERNATIVES,
} from '../data/nutritionData';
import {
  Utensils,
  Search,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  ShieldAlert,
  Info,
  Droplets,
  Plus,
  Check,
  RotateCcw,
  Sparkles,
  ShoppingBag,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Heart,
  ThumbsUp,
  ThumbsDown,
  BookOpen,
  MapPin,
  Flame,
  Wheat,
  Smile,
} from 'lucide-react';

const DIETARY_OPTIONS: { id: DietaryPreferenceType; label: string; icon: string; desc: string }[] = [
  { id: 'vegetarian', label: 'Vegetarian', icon: '🥦', desc: 'Plant foods, grains, pulses, dairy' },
  { id: 'eggetarian', label: 'Eggetarian', icon: '🥚', desc: 'Vegetarian plus well-cooked eggs' },
  { id: 'non_vegetarian', label: 'Non-Vegetarian', icon: '🍗', desc: 'Vegetarian plus poultry, fish, cooked meats' },
  { id: 'vegan', label: 'Vegan', icon: '🌱', desc: '100% plant-based, no dairy or honey' },
  { id: 'other', label: 'Custom / Other', icon: '🥗', desc: 'Specialized or personalized diet' },
];

const POPULAR_CITIES = [
  'Bengaluru',
  'Lucknow',
  'Delhi NCR',
  'Mumbai',
  'Kolkata',
  'Chennai',
  'Hyderabad',
  'Jaipur',
  'Pune',
];

export const DailyFoodGuide: React.FC = () => {
  const {
    language,
    pregnancy,
    nutritionProfile,
    updateNutritionProfile,
    dailyMealPlan,
    toggleMealItemStatus,
    groceryList,
    toggleGroceryItem,
    addGroceryItem,
    foodCity,
    setFoodCity,
    regenerateMealPlan,
  } = useApp();

  const isHi = language === 'hi';

  // Tabs within Nutrition View
  const [activeTab, setActiveTab] = useState<'meals' | 'canIEat' | 'localDishes' | 'alternatives' | 'grocery' | 'guidelines'>('meals');

  // "Can I Eat This?" search state
  const [searchDishQuery, setSearchDishQuery] = useState('');
  const [evaluatingDish, setEvaluatingDish] = useState(false);
  const [evaluatedResult, setEvaluatedResult] = useState<LocalDishEvaluation | null>(null);
  const [evalError, setEvalError] = useState<string | null>(null);

  // Grocery quick-add state
  const [newGroceryName, setNewGroceryName] = useState('');
  const [newGroceryQty, setNewGroceryQty] = useState('');
  const [newGroceryCat, setNewGroceryCat] = useState<GroceryItem['category']>('Fresh Produce');

  // Hydration state (glasses of 250ml)
  const [waterGlasses, setWaterGlasses] = useState(8); // 8 * 250ml = 2.0L
  const targetGlasses = 11; // ~2.75L per WHO / ICMR

  // Preferences modal/accordion
  const [showPrefEditor, setShowPrefEditor] = useState(false);

  // Evaluate Food with API + Fallback
  const handleEvaluateFood = async (dishName: string) => {
    if (!dishName.trim()) return;
    setEvaluatingDish(true);
    setEvalError(null);
    setSearchDishQuery(dishName);

    try {
      const response = await fetch('/api/evaluate-food', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dishName: dishName.trim(),
          pregnancyWeek: pregnancy.currentWeek,
          dietaryPreference: nutritionProfile.dietaryPreference,
          cityRegion: foodCity,
          foodAllergies: nutritionProfile.foodAllergies,
          medicalConditions: ['Pregnancy Week ' + pregnancy.currentWeek],
        }),
      });

      if (!response.ok) {
        throw new Error('Server returned ' + response.status);
      }
      const data = await response.json();
      setEvaluatedResult(data);
    } catch (err: any) {
      // Look up local database fallback
      const foundInDb = REGIONAL_FOOD_DATABASE.find(
        d =>
          d.dishName.toLowerCase().includes(dishName.toLowerCase()) ||
          d.famousFor.toLowerCase().includes(dishName.toLowerCase())
      );
      if (foundInDb) {
        setEvaluatedResult(foundInDb);
      } else {
        // Safe clinical fallback
        setEvaluatedResult({
          id: 'dish-custom-' + Date.now(),
          dishName: dishName,
          dishNameHi: dishName,
          cityRegion: foodCity,
          cuisine: 'Local Indian / Global',
          famousFor: 'User queried food item',
          status: 'suitable_with_modifications',
          statusLabel: 'Safe with preparation precautions',
          statusLabelHi: 'सावधानी व पूरी तरह पका कर खाना सुरक्षित',
          clinicalReason:
            'Ensure this dish is prepared hygienically, served steaming hot (>74°C), and made with pasteurized ingredients. Avoid raw unwashed garnishes or leftover street preparations.',
          clinicalReasonHi:
            'सुनिश्चित करें कि यह ताज़ा और अच्छी तरह पका हुआ हो। कच्ची चटनी या बासी भोजन से बचें।',
          portionTip: 'Consume a moderate homestyle portion alongside high-fiber vegetables.',
          healthyModification: 'Prepare with fresh home ingredients and hygienic thorough cooking (>74°C).',
          safetyCheck: {
            pregnancySafe: true,
            isRawOrUndercookedRisk: false,
            highSodiumOrSugarRisk: false,
            deepFriedRisk: false,
            potentialAllergens: [],
          },
          dietSuitability: [nutritionProfile.dietaryPreference],
          whoGuidelineAlignment: 'WHO Healthy Diet: Hygienic preparation and balanced portioning.',
        });
      }
    } finally {
      setEvaluatingDish(false);
    }
  };

  const filteredLocalDishes = REGIONAL_FOOD_DATABASE.filter(d =>
    foodCity ? d.cityRegion.toLowerCase() === foodCity.toLowerCase() : true
  );

  const getStatusBadge = (status: LocalDishEvaluation['status']) => {
    switch (status) {
      case 'suitable':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {isHi ? 'सुरक्षित व पौष्टिक' : 'Safe to eat as part of a balanced diet'}
          </span>
        );
      case 'suitable_with_modifications':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            {isHi ? 'सावधानी व संशोधन के साथ' : 'Safe with preparation precautions'}
          </span>
        );
      case 'limit_or_alternative':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-orange-50 text-orange-800 border border-orange-200">
            <Info className="w-4 h-4 text-orange-600" />
            {isHi ? 'सीमित मात्रा में लें' : 'Eat in moderation'}
          </span>
        );
      case 'avoid_safety_reason':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-800 border border-rose-200">
            <AlertOctagon className="w-4 h-4 text-rose-600" />
            {isHi ? 'गर्भावस्था में परहेज करें' : 'Avoid during pregnancy'}
          </span>
        );
      case 'insufficient_info':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-purple-50 text-purple-800 border border-purple-200">
            <ShieldAlert className="w-4 h-4 text-purple-600" />
            {isHi ? 'डॉक्टर से परामर्श लें' : 'Consult your doctor or dietitian'}
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Mumora Personalized Food Guide */}
      <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-purple-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute -right-8 -bottom-8 w-44 h-44 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold text-purple-100">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{isHi ? 'एआई वैयक्तिकृत दैनिक पोषण' : 'AI Personalized Daily Nutrition'}</span>
              <span>·</span>
              <span>Trimester {pregnancy.trimester} (Week {pregnancy.currentWeek})</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {isHi ? 'आपका दैनिक पोषण व आहार मार्गदर्शक' : 'Your Daily Food Guide'}
            </h1>
            <p className="text-purple-100 text-xs sm:text-sm leading-relaxed">
              {isHi
                ? 'आईसीएमआर-एनआईएन 2024 और डब्ल्यूएचओ दिशानिर्देशों के अनुसार, आपकी पसंद, एलर्जी, और स्थानीय व्यंजनों पर आधारित संतुलित आहार योजना।'
                : 'Culturally familiar, trimester-adapted meal slots, local street food safety checks, and hydration tracking calibrated to WHO & ICMR-NIN 2024 guidelines.'}
            </p>
          </div>

          {/* Quick Dietary Preference Pill */}
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4 flex flex-col gap-2 shrink-0 sm:min-w-[240px]">
            <div className="flex items-center justify-between text-xs text-purple-200">
              <span>{isHi ? 'आहार प्राथमिकता' : 'Dietary Preference'}</span>
              <button
                onClick={() => setShowPrefEditor(!showPrefEditor)}
                className="text-amber-300 font-bold hover:underline flex items-center gap-1 text-[11px]"
              >
                <span>{showPrefEditor ? (isHi ? 'पूर्ण' : 'Close') : (isHi ? 'बदलें' : 'Change')}</span>
                {showPrefEditor ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">
                {DIETARY_OPTIONS.find(d => d.id === nutritionProfile.dietaryPreference)?.icon || '🥦'}
              </span>
              <div>
                <p className="font-extrabold text-sm capitalize">
                  {DIETARY_OPTIONS.find(d => d.id === nutritionProfile.dietaryPreference)?.label || 'Vegetarian'}
                </p>
                <p className="text-[11px] text-purple-200 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-amber-300" />
                  <span>{foodCity}</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Expandable Preferences Customizer */}
        {showPrefEditor && (
          <div className="mt-6 pt-6 border-t border-white/20 grid grid-cols-1 md:grid-cols-2 gap-4 text-slate-800 bg-white rounded-2xl p-5 shadow-lg">
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Utensils className="w-3.5 h-3.5 text-purple-600" />
                <span>What type of food do you eat?</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                {DIETARY_OPTIONS.map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => {
                      updateNutritionProfile({ dietaryPreference: opt.id });
                      regenerateMealPlan();
                    }}
                    className={`p-2.5 rounded-xl text-left border transition-all text-xs flex items-center gap-2 ${
                      nutritionProfile.dietaryPreference === opt.id
                        ? 'bg-purple-50 border-purple-500 text-purple-900 font-bold shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <span className="text-lg">{opt.icon}</span>
                    <span className="truncate">{opt.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-purple-600" />
                <span>Your City / Regional Cuisine</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {POPULAR_CITIES.map(c => (
                  <button
                    key={c}
                    onClick={() => {
                      setFoodCity(c);
                      regenerateMealPlan();
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                      foodCity === c
                        ? 'bg-purple-700 text-white font-bold'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  onClick={() => {
                    regenerateMealPlan();
                    setShowPrefEditor(false);
                  }}
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 ml-auto"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Update & Regenerate Meals</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar border-b border-purple-100">
        {[
          { id: 'meals', label: isHi ? 'आज का भोजन' : "Today's Meals", icon: Utensils },
          { id: 'canIEat', label: isHi ? 'क्या मैं यह खा सकती हूँ?' : 'Can I Eat This?', icon: Search },
          { id: 'localDishes', label: isHi ? `${foodCity} के स्थानीय व्यंजन` : `Local Foods (${foodCity})`, icon: MapPin },
          { id: 'alternatives', label: isHi ? 'स्वस्थ विकल्प' : 'Healthy Swaps', icon: Wheat },
          { id: 'grocery', label: isHi ? 'स्मार्ट किराने की सूची' : 'Smart Grocery List', icon: ShoppingBag },
          { id: 'guidelines', label: isHi ? 'चिकित्सकीय प्रमाण' : 'Clinical Evidence', icon: BookOpen },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-purple-50 hover:text-purple-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: TODAY'S MEAL SLOTS (6 SLOTS + HYDRATION) */}
      {activeTab === 'meals' && (
        <div className="space-y-6">
          {/* Hydration & Nutrient Target Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Hydration Tracker */}
            <div className="bg-blue-50/70 border border-blue-200/80 rounded-2xl p-4.5 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-blue-500 text-white flex items-center justify-center shadow-xs">
                    <Droplets className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm">
                      {isHi ? 'दैनिक जल सेवन' : 'Daily Hydration'}
                    </h3>
                    <p className="text-[11px] text-blue-700 font-medium">
                      WHO Target: 2.5 - 3.0 Liters
                    </p>
                  </div>
                </div>
                <span className="font-extrabold text-blue-900 text-lg">
                  {(waterGlasses * 0.25).toFixed(1)} L
                </span>
              </div>

              {/* Glass Counter */}
              <div className="mt-3">
                <div className="flex items-center justify-between text-xs text-slate-600 mb-1.5">
                  <span>{waterGlasses} of {targetGlasses} glasses (250 ml each)</span>
                  <span className="font-bold text-blue-800">
                    {Math.min(100, Math.round((waterGlasses / targetGlasses) * 100))}%
                  </span>
                </div>
                <div className="w-full bg-blue-200/70 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (waterGlasses / targetGlasses) * 100)}%` }}
                  />
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <button
                    onClick={() => setWaterGlasses(prev => Math.max(0, prev - 1))}
                    className="flex-1 py-1.5 bg-white border border-blue-200 rounded-lg text-xs font-bold text-blue-700 hover:bg-blue-100"
                  >
                    - 1 Glass
                  </button>
                  <button
                    onClick={() => setWaterGlasses(prev => prev + 1)}
                    className="flex-1 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 shadow-xs flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    + 1 Glass
                  </button>
                </div>
              </div>
            </div>

            {/* Trimester Nutrient Addition (ICMR-NIN 2024) */}
            <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4.5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-amber-900 font-bold text-sm mb-1">
                  <Flame className="w-4 h-4 text-amber-600" />
                  <span>Trimester Energy Target</span>
                </div>
                <p className="text-xs text-slate-600">
                  {pregnancy.trimester === 1
                    ? '1st Trimester: Micronutrient quality over extra calories. Daily Folic Acid (400 mcg).'
                    : `+350 kcal/day & +23g protein/day recommended in ${pregnancy.trimester === 2 ? '2nd' : '3rd'} trimester (ICMR-NIN 2024).`}
                </p>
              </div>
              <div className="mt-3 pt-3 border-t border-amber-200/60 flex items-center justify-between text-xs">
                <span className="text-amber-800 font-semibold">Recommended Protein:</span>
                <span className="font-extrabold text-slate-800">~65 - 75g / day</span>
              </div>
            </div>

            {/* Doctor Consultation Disclaimer */}
            <div className="bg-purple-50/70 border border-purple-200/80 rounded-2xl p-4.5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-purple-900 font-bold text-sm mb-1">
                  <ShieldAlert className="w-4 h-4 text-purple-600" />
                  <span>Clinical Safety Boundary</span>
                </div>
                <p className="text-xs text-slate-600">
                  {isHi
                    ? 'पोषण योजनाएं पूरक मार्गदर्शन हैं। जेस्टेशनल डायबिटीज या हाइपरटेंशन में अपने डॉक्टर की सलाह का पालन करें।'
                    : 'Personalized food guidance complements antenatal care. If diagnosed with GDM or preeclampsia, adhere to your clinical prescription.'}
                </p>
              </div>
              <div className="mt-3 pt-3 border-t border-purple-200/60 flex items-center justify-between text-xs">
                <span className="text-purple-800 font-semibold">Regenerate anytime:</span>
                <button
                  onClick={regenerateMealPlan}
                  className="text-purple-700 font-bold hover:underline flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Refresh Dishes</span>
                </button>
              </div>
            </div>
          </div>

          {/* 6 Structured Daily Meal Slots */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Utensils className="w-4 h-4 text-purple-600" />
                <span>Today's 6 Recommended Meal Slots</span>
              </h2>
              <span className="text-xs text-slate-500">
                {dailyMealPlan.filter(m => m.isEaten).length} of {dailyMealPlan.length} logged
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {dailyMealPlan.map(slot => (
                <div
                  key={slot.id}
                  className={`border rounded-2xl p-4.5 transition-all ${
                    slot.isEaten
                      ? 'bg-emerald-50/40 border-emerald-300/80 shadow-xs'
                      : 'bg-white border-purple-100 hover:border-purple-300 shadow-xs'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-purple-100 text-purple-800">
                        {slot.slotLabel}
                      </span>
                      <h3 className="font-extrabold text-slate-900 text-sm">
                        {isHi ? slot.slotLabelHi : slot.slot}
                      </h3>
                    </div>

                    <button
                      onClick={() => toggleMealItemStatus(slot.id, 'isEaten')}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                        slot.isEaten
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800'
                      }`}
                      title={slot.isEaten ? 'Marked as consumed' : 'Click to mark consumed'}
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{slot.isEaten ? (isHi ? 'खाया गया' : 'Eaten') : (isHi ? 'मार्क करें' : 'Log')}</span>
                    </button>
                  </div>

                  {/* Dish Name & Description */}
                  <div className="mt-3">
                    <p className="font-bold text-slate-900 text-sm">
                      {isHi && slot.foodNameHi ? slot.foodNameHi : slot.foodName}
                    </p>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      {slot.description}
                    </p>
                  </div>

                  {/* Portion & Key Nutrients */}
                  <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px]">
                    <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium">
                      Portion: {slot.portionGuide}
                    </span>
                    {slot.mainIngredients.map((nut, i) => (
                      <span key={i} className="bg-purple-50 text-purple-800 px-2 py-0.5 rounded-md font-semibold">
                        {nut}
                      </span>
                    ))}
                  </div>

                  {/* Clinical Reason & Cooking Tip */}
                  <div className="mt-3 pt-3 border-t border-slate-100 text-xs space-y-1.5">
                    <div className="flex items-start gap-1.5 text-slate-600">
                      <Heart className="w-3.5 h-3.5 text-pink-500 shrink-0 mt-0.5" />
                      <span className="text-[11px] leading-relaxed">
                        <strong className="text-slate-800">Benefit:</strong> {isHi && slot.clinicalWhyHi ? slot.clinicalWhyHi : slot.clinicalWhy}
                      </span>
                    </div>
                    {slot.simplePreparation && slot.simplePreparation.length > 0 && (
                      <div className="flex items-start gap-1.5 text-slate-500">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                        <span className="text-[11px] leading-relaxed">
                          <strong className="text-slate-700">Kitchen Tip:</strong> {slot.simplePreparation[0]}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* User Feedback Buttons */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100/80 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleMealItemStatus(slot.id, 'isLiked')}
                        className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-all ${
                          slot.isLiked
                            ? 'bg-pink-50 border-pink-400 text-pink-700 font-bold'
                            : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                        }`}
                        title="Love this dish"
                      >
                        <ThumbsUp className="w-3 h-3" />
                        <span>Like</span>
                      </button>
                      <button
                        onClick={() => toggleMealItemStatus(slot.id, 'isDisliked')}
                        className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-all ${
                          slot.isDisliked
                            ? 'bg-rose-50 border-rose-400 text-rose-700 font-bold'
                            : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                        }`}
                        title="Don't recommend again"
                      >
                        <ThumbsDown className="w-3 h-3" />
                        <span>Dislike</span>
                      </button>
                    </div>

                    <button
                      onClick={() => toggleMealItemStatus(slot.id, 'isUnavailable')}
                      className={`text-[11px] font-medium transition-all ${
                        slot.isUnavailable
                          ? 'text-amber-700 underline font-bold'
                          : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      {slot.isUnavailable ? 'Unavailable today' : 'Not in pantry?'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: "CAN I EAT THIS?" LOCAL FOOD SAFETY CHECKER */}
      {activeTab === 'canIEat' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-purple-100 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
                <Search className="w-5 h-5 text-purple-600" />
                <span>Can I Eat This? — Local Food & Street Food Safety Checker</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                {isHi
                  ? 'किसी भी स्थानीय व्यंजन, स्ट्रीट फूड, फल या काढ़े का नाम लिखें या नीचे दिए गए लोकप्रिय व्यंजनों पर क्लिक करें।'
                  : 'Search any local Indian or global dish, herbal decoction (kadha), street food, or fruit to receive evidence-based safety evaluation with 5 clinical outcome categories.'}
              </p>
            </div>

            {/* Search Input Bar */}
            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={searchDishQuery}
                  onChange={e => setSearchDishQuery(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleEvaluateFood(searchDishQuery)}
                  placeholder="e.g. Raw Papaya, Street Pani Puri, Methi Ladoo, Gond Ladoo, Sushi, Haldi Doodh..."
                  className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <button
                onClick={() => handleEvaluateFood(searchDishQuery)}
                disabled={evaluatingDish || !searchDishQuery.trim()}
                className="px-6 py-2.5 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all flex items-center justify-center gap-2"
              >
                {evaluatingDish ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>Check Safety</span>
                  </>
                )}
              </button>
            </div>

            {/* Quick Query Chips for Famous Foods */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-500">Quick Check Popular Dishes & Traditional Foods:</p>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Raw Papaya Salad',
                  'Ripe Papaya',
                  'Street Pani Puri / Golgappe',
                  'Methi Ladoo',
                  'Gond Ladoo with Cow Ghee',
                  'Raw / Undercooked Sushi',
                  'Ajwain Kadha',
                  'Haldi Doodh (Turmeric Milk)',
                  'Lucknow Galouti Kebab (Well Cooked)',
                  'Unpasteurized Blue Cheese',
                  'Soft Boiled Half-Fry Egg',
                  'Tender Coconut Water',
                ].map(dish => (
                  <button
                    key={dish}
                    onClick={() => handleEvaluateFood(dish)}
                    className="px-3 py-1.5 rounded-lg text-xs bg-purple-50 text-purple-800 hover:bg-purple-100 border border-purple-100 transition-colors"
                  >
                    {dish}
                  </button>
                ))}
              </div>
            </div>

            {/* Evaluation Result Card */}
            {evaluatedResult && (
              <div className="mt-6 p-6 rounded-2xl border-2 border-purple-200 bg-gradient-to-br from-white to-purple-50/30 shadow-md space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-purple-100">
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-900">
                      {isHi && evaluatedResult.dishNameHi ? evaluatedResult.dishNameHi : evaluatedResult.dishName}
                    </h3>
                    <p className="text-xs text-slate-500">
                      Cuisine: {evaluatedResult.cuisine} · Region: {evaluatedResult.cityRegion}
                    </p>
                  </div>
                  <div>{getStatusBadge(evaluatedResult.status)}</div>
                </div>

                <div className="space-y-3 text-xs sm:text-sm">
                  <div>
                    <strong className="text-slate-800">Clinical Evaluation:</strong>
                    <p className="text-slate-700 mt-1 leading-relaxed">
                      {isHi && evaluatedResult.clinicalReasonHi ? evaluatedResult.clinicalReasonHi : evaluatedResult.clinicalReason}
                    </p>
                  </div>

                  {evaluatedResult.portionTip && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                      <strong className="text-amber-900 text-xs">Portion Guidance:</strong>
                      <p className="text-amber-800 text-xs mt-0.5">{evaluatedResult.portionTip}</p>
                    </div>
                  )}

                  {evaluatedResult.healthyModification && (
                    <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3">
                      <strong className="text-emerald-900 text-xs">Recommended Safe Modification:</strong>
                      <p className="text-emerald-800 text-xs mt-0.5">{evaluatedResult.healthyModification}</p>
                    </div>
                  )}

                  <div className="pt-2 text-[11px] text-slate-400 flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Evidence Alignment: {evaluatedResult.whoGuidelineAlignment}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: LOCAL DISHES NEAR ME */}
      {activeTab === 'localDishes' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-purple-600" />
                <span>Famous Local Dishes in {foodCity}</span>
              </h2>
              <p className="text-xs text-slate-500">
                Nutrient analysis and pregnancy suitability for regional delicacies.
              </p>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {POPULAR_CITIES.map(c => (
                <button
                  key={c}
                  onClick={() => setFoodCity(c)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                    foodCity === c
                      ? 'bg-purple-700 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredLocalDishes.map(dish => (
              <div
                key={dish.id}
                className="bg-white border border-purple-100 rounded-2xl p-4.5 shadow-xs space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-sm">
                        {isHi && dish.dishNameHi ? dish.dishNameHi : dish.dishName}
                      </h3>
                      <p className="text-[11px] text-slate-500">{dish.famousFor}</p>
                    </div>
                    {getStatusBadge(dish.status)}
                  </div>

                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    {isHi && dish.clinicalReasonHi ? dish.clinicalReasonHi : dish.clinicalReason}
                  </p>

                  {dish.portionTip && (
                    <div className="mt-2.5 bg-slate-50 p-2 rounded-lg text-[11px] text-slate-700">
                      <strong>Portion:</strong> {dish.portionTip}
                    </div>
                  )}
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span>{dish.cuisine}</span>
                  <span>{dish.whoGuidelineAlignment}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: HEALTHY FOOD ALTERNATIVES */}
      {activeTab === 'alternatives' && (
        <div className="space-y-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Wheat className="w-4 h-4 text-purple-600" />
              <span>Smart Nutritional Swaps & Affordable Alternatives</span>
            </h2>
            <p className="text-xs text-slate-500">
              Replace refined starches, ultra-processed street fats, and high-mercury seafood with nutrient-dense local staples.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SAMPLE_FOOD_ALTERNATIVES.map(item => (
              <div
                key={item.id}
                className="bg-white border border-purple-100 rounded-2xl p-5 shadow-xs space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-purple-50 text-purple-800">
                    {item.category}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-rose-50/60 border border-rose-100">
                    <p className="text-[11px] font-bold text-rose-700 uppercase">Avoid / Replace:</p>
                    <p className="text-xs font-semibold text-slate-800 mt-1">{item.originalFood}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-100">
                    <p className="text-[11px] font-bold text-emerald-700 uppercase">Recommended Swap:</p>
                    <p className="text-xs font-bold text-slate-800 mt-1">{item.recommendedAlternative}</p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  <strong>Why it matters:</strong> {isHi && item.clinicalAdvantageHi ? item.clinicalAdvantageHi : item.clinicalAdvantage}
                </p>

                <div className="bg-slate-50 p-2.5 rounded-xl text-[11px] text-slate-600">
                  <strong className="text-slate-800">Affordability:</strong> {item.affordableFactor}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: SMART GROCERY LIST */}
      {activeTab === 'grocery' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-purple-600" />
                <span>Smart Maternal & Baby Grocery Planner</span>
              </h2>
              <p className="text-xs text-slate-500">
                Weekly essentials categorized by nutrient density (WHO & ICMR-NIN).
              </p>
            </div>
            <div className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1.5 rounded-xl border border-purple-100">
              {groceryList.filter(g => g.checked).length} of {groceryList.length} items checked
            </div>
          </div>

          {/* Quick Add Form */}
          <div className="bg-white border border-purple-100 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row gap-2.5">
            <input
              type="text"
              value={newGroceryName}
              onChange={e => setNewGroceryName(e.target.value)}
              placeholder="Add item (e.g., Spinach / Palak, Ragi flour, Walnuts)..."
              className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <input
              type="text"
              value={newGroceryQty}
              onChange={e => setNewGroceryQty(e.target.value)}
              placeholder="Qty (e.g. 500g, 1 bunch)"
              className="w-full sm:w-32 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <button
              onClick={() => {
                if (newGroceryName.trim()) {
                  addGroceryItem(newGroceryName.trim(), newGroceryQty.trim() || '1 unit', newGroceryCat);
                  setNewGroceryName('');
                  setNewGroceryQty('');
                }
              }}
              className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Item</span>
            </button>
          </div>

          {/* Grocery Items List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {groceryList.map(item => (
              <div
                key={item.id}
                onClick={() => toggleGroceryItem(item.id)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  item.checked
                    ? 'bg-slate-50 border-slate-200 opacity-60'
                    : 'bg-white border-purple-100 hover:border-purple-300 shadow-xs'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${
                      item.checked
                        ? 'bg-emerald-600 text-white'
                        : 'border border-slate-300 bg-white'
                    }`}
                  >
                    {item.checked && <Check className="w-3.5 h-3.5" />}
                  </div>
                  <div>
                    <p className={`text-xs font-bold ${item.checked ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                      {item.name}
                    </p>
                    <span className="text-[10px] text-slate-400">{item.category}</span>
                  </div>
                </div>

                <span className="text-xs font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md">
                  {item.quantity}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: CLINICAL GUIDELINES & CITATIONS */}
      {activeTab === 'guidelines' && (
        <div className="space-y-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-purple-600" />
              <span>Verified Clinical References & Institutional Nutrition Standards</span>
            </h2>
            <p className="text-xs text-slate-500">
              Mumora's dietary engine is rigorously verified against WHO, ICMR-NIN, and FSSAI guidelines.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {WHO_NUTRITION_REFERENCES.map(ref => (
              <div
                key={ref.id}
                className="bg-white border border-purple-100 rounded-2xl p-5 shadow-xs space-y-2.5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h3 className="font-extrabold text-slate-900 text-sm">{ref.title}</h3>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-50 text-purple-800 border border-purple-100 w-fit">
                    {ref.issuingOrganization} · {ref.publicationYear}
                  </span>
                </div>

                <p className="text-xs text-purple-900 font-semibold">{ref.relevantSection}</p>
                <p className="text-xs text-slate-600 leading-relaxed">{ref.clinicalSummary}</p>

                <div className="pt-2">
                  <a
                    href={ref.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs text-purple-700 font-bold hover:underline"
                  >
                    <span>View Official Publication</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
