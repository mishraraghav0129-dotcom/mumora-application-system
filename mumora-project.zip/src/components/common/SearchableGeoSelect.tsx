import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Search, X, ChevronDown, Check, MapPin, Globe } from 'lucide-react';
import { filterAndSortGeoItems } from '../../data/geoData';

export interface GeoSelectItem {
  code: string;
  name: string;
  flag?: string;
  subtext?: string;
}

interface SearchableGeoSelectProps {
  label: string;
  required?: boolean;
  placeholder?: string;
  searchPlaceholder?: string;
  items: GeoSelectItem[];
  selectedCode?: string;
  selectedName?: string;
  onSelect: (item: GeoSelectItem) => void;
  onClear?: () => void;
  disabled?: boolean;
  disabledMessage?: string;
  emptyMessage?: string;
  icon?: React.ReactNode;
  isHi?: boolean;
}

export const SearchableGeoSelect: React.FC<SearchableGeoSelectProps> = ({
  label,
  required = false,
  placeholder = 'Select an option...',
  searchPlaceholder = 'Type to search...',
  items,
  selectedCode,
  selectedName,
  onSelect,
  onClear,
  disabled = false,
  disabledMessage,
  emptyMessage = 'No matching items found.',
  icon,
  isHi = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [highlightedIndex, setHighlightedIndex] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Focus search input when opened
  useEffect(() => {
    if (isOpen) {
      setSearchQuery('');
      setHighlightedIndex(0);
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  // Filtered and prioritized list
  const filteredItems = useMemo(() => {
    return filterAndSortGeoItems(items, searchQuery);
  }, [items, searchQuery]);

  // Selected item object
  const currentItem = useMemo(() => {
    if (selectedCode) {
      const match = items.find(i => i.code === selectedCode);
      if (match) return match;
    }
    if (selectedName) {
      const match = items.find(
        i => i.name.toLowerCase() === selectedName.toLowerCase()
      );
      if (match) return match;
    }
    return null;
  }, [items, selectedCode, selectedName]);

  const handleSelect = (item: GeoSelectItem) => {
    onSelect(item);
    setIsOpen(false);
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onClear) {
      onClear();
    }
    setSearchQuery('');
  };

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen) {
      if (e.key === 'Enter' || e.key === 'ArrowDown' || e.key === ' ') {
        if (!disabled) {
          e.preventDefault();
          setIsOpen(true);
        }
      }
      return;
    }

    if (e.key === 'Escape') {
      e.preventDefault();
      setIsOpen(false);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightedIndex(prev => (prev + 1 < filteredItems.length ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightedIndex(prev => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredItems[highlightedIndex]) {
        handleSelect(filteredItems[highlightedIndex]);
      }
    }
  };

  return (
    <div className="relative w-full" ref={containerRef}>
      {/* Label and Badge */}
      <div className="flex items-center justify-between mb-1">
        <label className="font-extrabold text-slate-700 text-xs flex items-center gap-1.5">
          {icon || <Globe className="w-3.5 h-3.5 text-purple-600" />}
          <span>{label}</span>
          {required && <span className="text-rose-500 font-black">*</span>}
        </label>
        {items.length > 0 && !disabled && (
          <span className="text-[10px] text-slate-600 font-semibold bg-slate-100 px-2 py-0.5 rounded-full">
            {items.length} {isHi ? 'उपलब्ध' : 'available'}
          </span>
        )}
      </div>

      {/* Trigger Button */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => {
          if (!disabled) setIsOpen(!isOpen);
        }}
        onKeyDown={handleKeyDown}
        title={disabled && disabledMessage ? disabledMessage : ''}
        className={`w-full px-3.5 py-2.5 rounded-xl border text-left flex items-center justify-between transition-all duration-200 text-xs ${
          disabled
            ? 'bg-slate-100/80 border-slate-200 text-slate-400 cursor-not-allowed'
            : isOpen
            ? 'border-purple-600 bg-white ring-2 ring-purple-100 shadow-sm'
            : 'border-slate-300 bg-white hover:border-purple-400 text-slate-800'
        }`}
      >
        <div className="flex items-center gap-2 truncate pr-2">
          {currentItem ? (
            <>
              {currentItem.flag && <span className="text-base shrink-0 leading-none">{currentItem.flag}</span>}
              <span className="font-bold text-slate-900 truncate">{currentItem.name}</span>
              {currentItem.code && (
                <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
                  ({currentItem.code})
                </span>
              )}
            </>
          ) : (
            <span className={disabled ? 'text-slate-400' : 'text-slate-400'}>
              {disabled && disabledMessage ? disabledMessage : placeholder}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {currentItem && onClear && !disabled && (
            <span
              role="button"
              tabIndex={0}
              onClick={handleClear}
              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
              title={isHi ? 'चयन हटाएं' : 'Clear selection'}
            >
              <X className="w-3.5 h-3.5" />
            </span>
          )}
          <ChevronDown
            className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
              isOpen ? 'rotate-180 text-purple-600' : ''
            }`}
          />
        </div>
      </button>

      {/* Dropdown / Selection Panel */}
      {isOpen && (
        <div className="absolute z-50 left-0 right-0 mt-1.5 bg-white border border-purple-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 max-h-[340px] flex flex-col">
          {/* Search Header */}
          <div className="p-2.5 bg-purple-50/70 border-b border-purple-100 shrink-0">
            <div className="relative">
              <Search className="w-4 h-4 text-purple-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={e => {
                  setSearchQuery(e.target.value);
                  setHighlightedIndex(0);
                }}
                onKeyDown={handleKeyDown}
                placeholder={searchPlaceholder}
                className="w-full pl-9 pr-8 py-2 bg-white border border-purple-200 rounded-xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-purple-400"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    searchInputRef.current?.focus();
                  }}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {searchQuery && (
              <div className="flex items-center justify-between mt-1.5 px-1 text-[11px] text-purple-700">
                <span>
                  {isHi ? 'खोज परिणाम:' : 'Matching results:'}{' '}
                  <strong className="font-extrabold">{filteredItems.length}</strong>
                </span>
                <span className="text-[10px] text-slate-500">
                  {isHi ? 'शीर्ष पर सबसे सटीक मिलान' : 'Ranked by best match'}
                </span>
              </div>
            )}
          </div>

          {/* List Items */}
          <div
            ref={listRef}
            className="overflow-y-auto divide-y divide-slate-100 flex-1 p-1 max-h-[260px] scrollbar-thin"
          >
            {filteredItems.length === 0 ? (
              <div className="py-8 px-4 text-center space-y-1">
                <MapPin className="w-6 h-6 text-slate-300 mx-auto" />
                <p className="text-xs font-bold text-slate-600">{emptyMessage}</p>
                <p className="text-[11px] text-slate-400">
                  {isHi
                    ? `"${searchQuery}" के लिए कोई परिणाम नहीं मिला।`
                    : `No records found matching "${searchQuery}".`}
                </p>
              </div>
            ) : (
              filteredItems.map((item, idx) => {
                const isSelected =
                  (selectedCode && item.code === selectedCode) ||
                  (selectedName && item.name.toLowerCase() === selectedName.toLowerCase());
                const isHighlighted = idx === highlightedIndex;

                return (
                  <button
                    key={`${item.code}-${idx}`}
                    type="button"
                    onClick={() => handleSelect(item)}
                    onMouseEnter={() => setHighlightedIndex(idx)}
                    className={`w-full px-3 py-2.5 rounded-xl text-left text-xs transition-colors flex items-center justify-between gap-2 ${
                      isSelected
                        ? 'bg-purple-100/70 text-purple-900 font-extrabold'
                        : isHighlighted
                        ? 'bg-purple-50 text-purple-900'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      {item.flag && <span className="text-base shrink-0 leading-none">{item.flag}</span>}
                      <span className="truncate">{item.name}</span>
                      {item.subtext && (
                        <span className="text-[10px] text-slate-400 font-normal truncate">
                          • {item.subtext}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {item.code && (
                        <span className="text-[10px] text-slate-400 font-mono px-1.5 py-0.5 bg-slate-100 rounded">
                          {item.code}
                        </span>
                      )}
                      {isSelected && <Check className="w-4 h-4 text-purple-700" />}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
