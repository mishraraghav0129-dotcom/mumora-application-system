import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { EmergencyModal } from './components/EmergencyModal';
import { PregnancyTracker } from './components/PregnancyTracker';
import { BabyTracker } from './components/BabyTracker';
import { AiAssistant } from './components/AiAssistant';
import { DocumentVault } from './components/DocumentVault';
import { PostpartumCare } from './components/PostpartumCare';
import { AdminBlueprint } from './components/AdminBlueprint';
import { NearestHospitals } from './components/NearestHospitals';
import { SmartReminders } from './components/SmartReminders';
import { DailyFoodGuide } from './components/DailyFoodGuide';
import { EnvironmentalHealthIntelligence } from './components/EnvironmentalHealthIntelligence';
import { FamilyHealthAndRiskInsights } from './components/FamilyHealthAndRiskInsights';
import { OnboardingFlow } from './components/OnboardingFlow';
import { ShieldCheck, Heart, AlertCircle, PhoneCall, Sparkles, Globe } from 'lucide-react';
import { TRANSLATIONS } from './data/translations';

const MainContent: React.FC = () => {
  const { appMode, language, setShowEmergencyModal } = useApp();
  const t = TRANSLATIONS[language];

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-slate-900">
      <Header />
      <EmergencyModal />
      <OnboardingFlow />

      {/* Mumora Brand Welcome Banner */}
      <div className="bg-gradient-to-r from-purple-100/50 via-pink-50/50 to-amber-50/40 border-b border-purple-100/60 py-2.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <img
              src="/mumora-logo.png"
              alt="Mumora Emblem"
              className="w-5 h-5 rounded-md object-contain shrink-0"
            />
            <span className="font-bold text-slate-800">Mumora</span>
            <span className="text-slate-300 hidden sm:inline">·</span>
            <span className="text-purple-700 font-medium truncate flex items-center gap-1">
              <span>Healthy Moms</span>
              <span className="text-pink-500">♥</span>
              <span>Brighter Tomorrows</span>
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0 text-[11px] text-slate-500">
            <span className="hidden md:inline-flex items-center gap-1 text-emerald-700 font-medium">
              <ShieldCheck className="w-3.5 h-3.5" />
              WHO Guidelines
            </span>
            <span className="hidden sm:inline-flex items-center gap-1 text-purple-700 font-medium">
              <Globe className="w-3 h-3" />
              45+ World Languages
            </span>
          </div>
        </div>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {appMode === 'pregnancy' && <PregnancyTracker />}
        {appMode === 'baby' && <BabyTracker />}
        {appMode === 'reminders' && <SmartReminders />}
        {appMode === 'nutrition' && <DailyFoodGuide />}
        {appMode === 'environmental' && <EnvironmentalHealthIntelligence />}
        {(appMode === 'risk-insights' || appMode === 'family-health') && <FamilyHealthAndRiskInsights />}
        {appMode === 'assistant' && <AiAssistant />}
        {appMode === 'vault' && <DocumentVault />}
        {appMode === 'hospitals' && <NearestHospitals />}
        {appMode === 'postpartum' && <PostpartumCare />}
        {appMode === 'admin' && <AdminBlueprint />}
      </main>

      {/* Clean, premium Mumora healthcare footer */}
      <footer className="mt-auto border-t border-purple-100/70 bg-white/90 backdrop-blur-md py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <img
              src="/mumora-logo.png"
              alt="Mumora Logo"
              className="w-9 h-9 rounded-xl object-contain border border-purple-100 p-0.5 bg-white shadow-xs shrink-0"
            />
            <div className="space-y-0.5 text-left">
              <p className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <span>Mumora</span>
                <span className="text-xs font-normal text-purple-700">· Healthy Moms ♥ Brighter Tomorrows</span>
              </p>
              <p className="text-[11px] text-slate-400">
                {language === 'hi'
                  ? 'चिकित्सा सूचना केवल शैक्षणिक संदर्भ के लिए है। किसी भी आपात स्थिति में तुरंत 108 या 102 डायल करें।'
                  : 'Educational clinical information. Never a substitute for doctor consultation. Call 108 / 102 in emergency.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 text-[11px]">
            <button
              onClick={() => setShowEmergencyModal(true)}
              className="text-red-600 font-semibold hover:underline flex items-center gap-1"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? '108 आपातकालीन सेवा' : 'Emergency 108'}</span>
            </button>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>DPDPA 2023 Compliant</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>WHO & UIP Standards</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
