import { LanguageItem } from '../types';

export const WORLD_LANGUAGES: LanguageItem[] = [
  // Americas & Europe
  { code: 'en', name: 'English', nativeName: 'English', origin: 'Americas & Europe', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', origin: 'Americas & Europe', flag: '🇪🇸' },
  { code: 'fr', name: 'French', nativeName: 'Français', origin: 'Americas & Europe', flag: '🇫🇷' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', origin: 'Americas & Europe', flag: '🇧🇷' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', origin: 'Americas & Europe', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', origin: 'Americas & Europe', flag: '🇮🇹' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', origin: 'Americas & Europe', flag: '🇷🇺' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', origin: 'Americas & Europe', flag: '🇳🇱' },
  { code: 'pl', name: 'Polish', nativeName: 'Polski', origin: 'Americas & Europe', flag: '🇵🇱' },
  { code: 'uk', name: 'Ukrainian', nativeName: 'Українська', origin: 'Americas & Europe', flag: '🇺🇦' },
  { code: 'ro', name: 'Romanian', nativeName: 'Română', origin: 'Americas & Europe', flag: '🇷🇴' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά', origin: 'Americas & Europe', flag: '🇬🇷' },
  { code: 'cs', name: 'Czech', nativeName: 'Čeština', origin: 'Americas & Europe', flag: '🇨🇿' },
  { code: 'hu', name: 'Hungarian', nativeName: 'Magyar', origin: 'Americas & Europe', flag: '🇭🇺' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska', origin: 'Americas & Europe', flag: '🇸🇪' },

  // South Asia
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', origin: 'South Asia', flag: '🇧🇩' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', origin: 'South Asia', flag: '🇵🇰', rtl: true },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'or', name: 'Odia', nativeName: 'ଓଡ଼ିଆ', origin: 'South Asia', flag: '🇮🇳' },
  { code: 'ne', name: 'Nepali', nativeName: 'नेपाली', origin: 'South Asia', flag: '🇳🇵' },
  { code: 'as', name: 'Assamese', nativeName: 'অসমীয়া', origin: 'South Asia', flag: '🇮🇳' },

  // East & Southeast Asia
  { code: 'zh', name: 'Chinese (Simplified)', nativeName: '简体中文', origin: 'East & Southeast Asia', flag: '🇨🇳' },
  { code: 'zh-TW', name: 'Chinese (Traditional)', nativeName: '繁體中文', origin: 'East & Southeast Asia', flag: '🇹🇼' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', origin: 'East & Southeast Asia', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', origin: 'East & Southeast Asia', flag: '🇰🇷' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', origin: 'East & Southeast Asia', flag: '🇻🇳' },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia', origin: 'East & Southeast Asia', flag: '🇮🇩' },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu', origin: 'East & Southeast Asia', flag: '🇲🇾' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย', origin: 'East & Southeast Asia', flag: '🇹🇭' },
  { code: 'fil', name: 'Filipino', nativeName: 'Tagalog', origin: 'East & Southeast Asia', flag: '🇵🇭' },
  { code: 'my', name: 'Burmese', nativeName: 'မြန်မာဘာသာ', origin: 'East & Southeast Asia', flag: '🇲🇲' },

  // Middle East & North Africa (MENA)
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', origin: 'Middle East & North Africa', flag: '🇸🇦', rtl: true },
  { code: 'fa', name: 'Persian', nativeName: 'فارسی', origin: 'Middle East & North Africa', flag: '🇮🇷', rtl: true },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', origin: 'Middle East & North Africa', flag: '🇹🇷' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית', origin: 'Middle East & North Africa', flag: '🇮🇱', rtl: true },

  // Sub-Saharan Africa
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', origin: 'Sub-Saharan Africa', flag: '🇰🇪' },
  { code: 'ha', name: 'Hausa', nativeName: 'Harshen Hausa', origin: 'Sub-Saharan Africa', flag: '🇳🇬' },
  { code: 'yo', name: 'Yoruba', nativeName: 'Èdè Yorùbá', origin: 'Sub-Saharan Africa', flag: '🇳🇬' },
  { code: 'am', name: 'Amharic', nativeName: 'አማርኛ', origin: 'Sub-Saharan Africa', flag: '🇪🇹' },
  { code: 'zu', name: 'Zulu', nativeName: 'isiZulu', origin: 'Sub-Saharan Africa', flag: '🇿🇦' },
  { code: 'so', name: 'Somali', nativeName: 'Af-Soomaali', origin: 'Sub-Saharan Africa', flag: '🇸🇴' },
];

export interface TranslationSchema {
  appName: string;
  tagline: string;
  nav: {
    pregnancy: string;
    baby: string;
    reminders?: string;
    nutrition?: string;
    aiAssistant: string;
    vault: string;
    postpartum: string;
    hospitals: string;
    adminBlueprint: string;
  };
  emergency: {
    call108: string;
    call102: string;
    title: string;
    subtitle: string;
    redFlags: string[];
    close: string;
    quickDial: string;
  };
  pregnancy: {
    weekTitle: string;
    trimester: string;
    daysToGo: string;
    dueDate: string;
    babySize: string;
    length: string;
    weight: string;
    vitalLogs: string;
    bpSystolic: string;
    bpDiastolic: string;
    currentWeight: string;
    bloodSugar: string;
    logVitalsBtn: string;
    kickCounter: string;
    kickCounterDesc: string;
    startKicks: string;
    recordKick: string;
    contractionTimer: string;
    contractionDesc: string;
    startContraction: string;
    stopContraction: string;
    hospitalBag: string;
    docQuestions: string;
  };
  baby: {
    profile: string;
    age: string;
    growthChart: string;
    feedingTracker: string;
    diaperTracker: string;
    sleepTracker: string;
    vaccinationCard: string;
    startNursingLeft: string;
    startNursingRight: string;
    formulaMl: string;
    logFeeding: string;
    wetDiaper: string;
    dirtyDiaper: string;
    mixedDiaper: string;
    logDiaper: string;
    logGrowth: string;
    weightKg: string;
    lengthCm: string;
    headCircumference: string;
  };
  assistant: {
    title: string;
    subtitle: string;
    inputPlaceholder: string;
    send: string;
    thinking: string;
    disclaimer: string;
    quickPrompts: string[];
  };
  records: {
    title: string;
    subtitle: string;
    uploadBtn: string;
    analyzeBtn: string;
    categoryAll: string;
    categoryUltrasound: string;
    categoryBlood: string;
    categoryPrescription: string;
    categoryVaccine: string;
  };
  postpartum: {
    title: string;
    subtitle: string;
    lochiaTracker: string;
    epdsTitle: string;
    epdsDesc: string;
    takeEpds: string;
    pelvicFloor: string;
  };
  common: {
    save: string;
    cancel: string;
    delete: string;
    view: string;
    edit: string;
    normal: string;
    attention: string;
    date: string;
    time: string;
    notes: string;
    completed: string;
    pending: string;
  };
}

const EN_TRANSLATION: TranslationSchema = {
  appName: "Mumora",
  tagline: "Healthy Moms ♥ Brighter Tomorrows",
  nav: {
    pregnancy: "Pregnancy Track",
    baby: "Baby & Growth",
    reminders: "Vaccine Reminders",
    nutrition: "Daily Food Guide",
    aiAssistant: "Mumora AI Chat",
    vault: "Medical Records",
    postpartum: "Postpartum & Mood",
    hospitals: "Nearest Hospitals",
    adminBlueprint: "System Blueprint",
  },
  emergency: {
    call108: "Call 108 (Ambulance)",
    call102: "Call 102 (Janani Shishu)",
    title: "Obstetric & Pediatric Emergency Guidelines",
    subtitle: "If you observe warning signs, visit a hospital labor room immediately.",
    redFlags: [
      "Vaginal bleeding or brown spotting",
      "Decreased or absent fetal movements after 24-28 weeks",
      "Severe persistent headache with blurred vision or spots",
      "Sudden intense facial, hand, or ankle swelling",
      "Severe abdominal or upper right quadrant stomach pain",
      "Clear fluid leaking from the vagina (water breaking)",
      "High fever > 100.4°F (38°C) or severe chills",
      "For baby: High fever, breathing difficulty, grunting, blue lips"
    ],
    close: "Dismiss",
    quickDial: "Immediate Help"
  },
  pregnancy: {
    weekTitle: "Week of Pregnancy",
    trimester: "Trimester",
    daysToGo: "days remaining",
    dueDate: "Estimated Due Date (EDD)",
    babySize: "Baby is the size of a",
    length: "Length",
    weight: "Weight",
    vitalLogs: "Maternal Vitals & Logs",
    bpSystolic: "Systolic BP (mmHg)",
    bpDiastolic: "Diastolic BP (mmHg)",
    currentWeight: "Maternal Weight (kg)",
    bloodSugar: "Blood Sugar (mg/dL)",
    logVitalsBtn: "Log Today's Vitals",
    kickCounter: "Fetal Kick Counter",
    kickCounterDesc: "Target: 10 movements within 2 hours while resting on your left side.",
    startKicks: "Start Session",
    recordKick: "Tap for Kick (+1)",
    contractionTimer: "Labor Contraction Timer",
    contractionDesc: "Track duration and frequency. Follow the 5-1-1 rule.",
    startContraction: "Contraction Started",
    stopContraction: "Contraction Ended",
    hospitalBag: "Hospital Bag Checklist",
    docQuestions: "Doctor Visit Questions",
  },
  baby: {
    profile: "Baby Profile",
    age: "Age",
    growthChart: "WHO Growth Percentiles",
    feedingTracker: "Feeding & Nursing Tracker",
    diaperTracker: "Diaper Tracker",
    sleepTracker: "Sleep Tracker",
    vaccinationCard: "India National Vaccine Schedule",
    startNursingLeft: "Left Breast (L)",
    startNursingRight: "Right Breast (R)",
    formulaMl: "Formula Milk (ml)",
    logFeeding: "Save Feeding",
    wetDiaper: "Wet Diaper",
    dirtyDiaper: "Dirty Diaper",
    mixedDiaper: "Both (Wet + Dirty)",
    logDiaper: "Save Diaper Change",
    logGrowth: "Log Growth Measurement",
    weightKg: "Weight (kg)",
    lengthCm: "Length (cm)",
    headCircumference: "Head Circumference (cm)",
  },
  assistant: {
    title: "Mumora AI Health Companion",
    subtitle: "Clinically grounded advice in all world languages. Not a replacement for a doctor.",
    inputPlaceholder: "Ask about your week, test reports, baby care, or nutrition...",
    send: "Send",
    thinking: "Analyzing clinical guidelines...",
    disclaimer: "Medical Safety Notice: Mumora AI provides educational guidance based on clinical standards. It cannot provide definitive medical diagnoses, prescriptions, or emergency care.",
    quickPrompts: [
      "How many kicks should I feel at 28 weeks?",
      "What does AFI 12 cm mean in my ultrasound?",
      "Iron and Calcium medicines: How to take them properly?",
      "Postpartum care and traditional Indian diet tips",
      "Baby has not passed stool for 2 days, is it normal?"
    ]
  },
  records: {
    title: "Medical Document Vault & AI Explainer",
    subtitle: "Securely store ultrasound scans, blood tests, prescriptions, and extract clinical summaries.",
    uploadBtn: "Upload Report or Scan",
    analyzeBtn: "Explain With AI",
    categoryAll: "All Documents",
    categoryUltrasound: "Ultrasound Scans",
    categoryBlood: "Blood Tests",
    categoryPrescription: "Prescriptions",
    categoryVaccine: "Vaccine Cards",
  },
  postpartum: {
    title: "Postpartum Recovery & Emotional Wellbeing",
    subtitle: "Fourth Trimester healing: Body recovery, emotional health, and breastfeeding support.",
    lochiaTracker: "Lochia (Postpartum Bleeding) Guide",
    epdsTitle: "Edinburgh Postnatal Depression Screening (EPDS)",
    epdsDesc: "A gentle 10-question self-reflection for mothers in the first year postpartum.",
    takeEpds: "Start Emotional Wellbeing Check",
    pelvicFloor: "Pelvic Floor (Kegel) Exercises",
  },
  common: {
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    view: "View",
    edit: "Edit",
    normal: "Normal",
    attention: "Consult Doctor",
    date: "Date",
    time: "Time",
    notes: "Notes",
    completed: "Completed",
    pending: "Pending",
  }
};

const HI_TRANSLATION: TranslationSchema = {
  appName: "Mumora (म्यूमोरा)",
  tagline: "Healthy Moms ♥ Brighter Tomorrows",
  nav: {
    pregnancy: "गर्भावस्था ट्रैकर",
    baby: "शिशु एवं विकास",
    reminders: "टीकाकरण रिमाइंडर",
    nutrition: "आहार एवं भोजन",
    aiAssistant: "Mumora AI परामर्श",
    vault: "मेडिकल रिपोर्ट्स",
    postpartum: "प्रसवोत्तर स्वास्थ्य",
    hospitals: "निकटतम अस्पताल",
    adminBlueprint: "सिस्टम ब्लूप्रिंट",
  },
  emergency: {
    call108: "108 पर कॉल करें (एम्बुलेंस)",
    call102: "102 जननी एक्सप्रेस",
    title: "आपातकालीन चेतावनी एवं मार्गदर्शन",
    subtitle: "यदि कोई गंभीर लक्षण दिखाई दे, तो तुरंत नजदीकी प्रसूति अस्पताल जाएं।",
    redFlags: [
      "रक्तस्राव (Bleeding) या भूरे रंग के धब्बे",
      "24-28 सप्ताह बाद शिशु की हलचल में कमी या बंद होना",
      "तेज लगातार सिरदर्द, आंखों के आगे अंधेरा या धुंधला दिखना",
      "चेहरे, हाथों या पैरों में अचानक अत्यधिक सूजन",
      "पेट के ऊपरी हिस्से में तेज असहनीय दर्द",
      "योनि से पानी का बहना (Water Breaking)",
      "तेज बुखार (100.4°F / 38°C से अधिक) या कंपकंपी",
      "शिशु के लिए: तेज बुखार, सांस लेने में परेशानी, नीले होंठ"
    ],
    close: "बंद करें",
    quickDial: "तत्काल सहायता"
  },
  pregnancy: {
    weekTitle: "गर्भावस्था का सप्ताह",
    trimester: "तिमाही",
    daysToGo: "दिन शेष",
    dueDate: "अनुमानित प्रसव तिथि (EDD)",
    babySize: "बच्चा इस आकार का है:",
    length: "लंबाई",
    weight: "वजन",
    vitalLogs: "मां के स्वास्थ्य आंकड़े (Vitals)",
    bpSystolic: "सिस्टोलिक बीपी (mmHg)",
    bpDiastolic: "डायस्टोलिक बीपी (mmHg)",
    currentWeight: "मां का वजन (किग्रा)",
    bloodSugar: "ब्लड शुगर (mg/dL)",
    logVitalsBtn: "आज के आंकड़े दर्ज करें",
    kickCounter: "शिशु किक काउंटर (Fetal Kicks)",
    kickCounterDesc: "लक्ष्य: बाईं करवट लेटकर 2 घंटे में 10 हलचलें।",
    startKicks: "सत्र शुरू करें",
    recordKick: "किक दर्ज करें (+1)",
    contractionTimer: "प्रसव पीड़ा (संकुचन) टाइमर",
    contractionDesc: "संकुचन की अवधि और अंतराल नोट करें। 5-1-1 नियम का पालन करें।",
    startContraction: "संकुचन शुरू हुआ",
    stopContraction: "संकुचन समाप्त",
    hospitalBag: "हॉस्पिटल बैग की तैयारी",
    docQuestions: "डॉक्टर से पूछने योग्य प्रश्न",
  },
  baby: {
    profile: "शिशु प्रोफ़ाइल",
    age: "उम्र",
    growthChart: "WHO विकास चार्ट (पर्सेंटाइल)",
    feedingTracker: "स्तनपान एवं फीडिंग ट्रैकर",
    diaperTracker: "डायपर लॉग (गीला / गंदा)",
    sleepTracker: "नींद ट्रैकर",
    vaccinationCard: "राष्ट्रीय टीकाकरण तालिका (UIP/IAP)",
    startNursingLeft: "बायां स्तन (L)",
    startNursingRight: "दायां स्तन (R)",
    formulaMl: "फॉर्मूला दूध (मि.ली.)",
    logFeeding: "फीडिंग सेव करें",
    wetDiaper: "गीला डायपर",
    dirtyDiaper: "गंदा डायपर",
    mixedDiaper: "दोनों (गीला + गंदा)",
    logDiaper: "डायपर दर्ज करें",
    logGrowth: "विकास माप दर्ज करें",
    weightKg: "वजन (किग्रा)",
    lengthCm: "लंबाई (सेमी)",
    headCircumference: "सिर का घेरा (सेमी)",
  },
  assistant: {
    title: "Mumora AI स्वास्थ्य सहायिका",
    subtitle: "सटीक चिकित्सीय मार्गदर्शन। डॉक्टर का विकल्प नहीं।",
    inputPlaceholder: "गर्भावस्था, अल्ट्रासाउंड रिपोर्ट, पोषण या शिशु देखभाल के बारे में पूछें...",
    send: "भेजें",
    thinking: "क्लिनिकल मार्गदर्शन तैयार किया जा रहा है...",
    disclaimer: "चिकित्सा सुरक्षा सूचना: Mumora AI केवल शैक्षणिक जानकारी प्रदान करती है। यह किसी डॉक्टर की जांच, नुस्खे या आपातकालीन उपचार का विकल्प नहीं है।",
    quickPrompts: [
      "28वें हफ्ते में बच्चे की हलचल कितनी बार महसूस होनी चाहिए?",
      "अल्ट्रासाउंड रिपोर्ट में AFI 12 सेमी का क्या अर्थ है?",
      "आयरन और कैल्शियम की गोलियां लेने का सही समय क्या है?",
      "डिलीवरी के बाद पारंपरिक पोषण और सावधानी",
      "बच्चे ने 2 दिन से पॉटी नहीं की, क्या यह सामान्य है?"
    ]
  },
  records: {
    title: "मेडिकल दस्तावेज़ और AI रिपोर्ट विश्लेषण",
    subtitle: "अल्ट्रासाउंड, ब्लड टेस्ट और डॉक्टर के पर्चे सुरक्षित रखें व आसान भाषा में समझें।",
    uploadBtn: "रिपोर्ट / स्कैन अपलोड करें",
    analyzeBtn: "AI से समझें",
    categoryAll: "सभी दस्तावेज़",
    categoryUltrasound: "अल्ट्रासाउंड सोनोग्राफी",
    categoryBlood: "ब्लड टेस्ट",
    categoryPrescription: "डॉक्टर के पर्चे",
    categoryVaccine: "टीकाकरण कार्ड",
  },
  postpartum: {
    title: "प्रसवोत्तर स्वास्थ्य एवं मानसिक देखभाल",
    subtitle: "चौथी तिमाही: शरीर का स्वस्थ होना, भावनात्मक स्वास्थ्य और स्तनपान सहयोग।",
    lochiaTracker: "लोकिया (प्रसवोत्तर रक्तस्राव) गाइड",
    epdsTitle: "प्रसवोत्तर अवसाद जांच प्रश्नावली (EPDS)",
    epdsDesc: "शिशु जन्म के बाद माताओं के मानसिक स्वास्थ्य की 10 प्रश्नों वाली सुरक्षित जांच।",
    takeEpds: "मानसिक स्वास्थ्य जांच शुरू करें",
    pelvicFloor: "पेल्विक फ्लोर (कीगल) व्यायाम",
  },
  common: {
    save: "सुरक्षित करें",
    cancel: "रद्द करें",
    delete: "हटाएं",
    view: "देखें",
    edit: "संपादित करें",
    normal: "सामान्य",
    attention: "डॉक्टर से सलाह लें",
    date: "दिनांक",
    time: "समय",
    notes: "टिप्पणी",
    completed: "पूर्ण",
    pending: "बाकी",
  }
};

const ES_TRANSLATION: TranslationSchema = {
  ...EN_TRANSLATION,
  appName: "Mumora",
  tagline: "Healthy Moms ♥ Brighter Tomorrows",
  nav: {
    pregnancy: "Seguimiento Embarazo",
    baby: "Bebé y Crecimiento",
    aiAssistant: "Chat Mumora AI",
    vault: "Historial Médico",
    postpartum: "Puerperio y Emoción",
    hospitals: "Hospitales Cercanos",
    adminBlueprint: "Arquitectura Técnica",
  },
  emergency: {
    call108: "Llamar Emergencias (112 / 911)",
    call102: "Ambulancia Obstétrica",
    title: "Guía de Emergencias Obstétricas y Pediátricas",
    subtitle: "Si observa señales de alerta, acuda de inmediato a urgencias.",
    redFlags: [
      "Sangrado vaginal o manchado marrón",
      "Disminución o ausencia de movimientos fetales después de las 24-28 semanas",
      "Dolor de cabeza intenso y constante con visión borrosa o destellos",
      "Hinchazón repentina en cara, manos o tobillos",
      "Dolor abdominal agudo o en el cuadrante superior derecho",
      "Pérdida de líquido amniótico transparente (rotura de aguas)",
      "Fiebre alta > 38°C (100.4°F) o escalofríos intensos",
      "Para el bebé: Fiebre alta, dificultad para respirar, quejidos, labios azulados"
    ],
    close: "Cerrar",
    quickDial: "Ayuda Inmediata"
  },
  pregnancy: {
    ...EN_TRANSLATION.pregnancy,
    weekTitle: "Semana de Embarazo",
    trimester: "Trimestre",
    daysToGo: "días restantes",
    dueDate: "Fecha Probable de Parto (FPP)",
    babySize: "El bebé tiene el tamaño de",
    length: "Longitud",
    weight: "Peso",
    vitalLogs: "Signos Vitales Maternos",
    kickCounter: "Contador de Movimientos Fetales",
    contractionTimer: "Temporizador de Contracciones",
    hospitalBag: "Maleta para el Hospital",
  },
  baby: {
    ...EN_TRANSLATION.baby,
    profile: "Perfil del Bebé",
    age: "Edad",
    growthChart: "Percentiles de Crecimiento OMS",
    feedingTracker: "Registro de Lactancia y Alimentación",
    diaperTracker: "Control de Pañales",
    sleepTracker: "Control del Sueño",
    vaccinationCard: "Cartilla de Vacunación",
  },
  assistant: {
    title: "Asistente Materno Mumora AI",
    subtitle: "Orientación clínica en español. No sustituye la consulta médica.",
    inputPlaceholder: "Pregunte sobre su semana, ecografía, nutrición o cuidados del recién nacido...",
    send: "Enviar",
    thinking: "Analizando pautas clínicas...",
    disclaimer: "Aviso de Seguridad Médica: Mumora AI proporciona orientación educativa basada en protocolos clínicos. No emite diagnósticos ni prescripciones.",
    quickPrompts: [
      "¿Cuántos movimientos fetales debo sentir en la semana 28?",
      "¿Qué significa un ILA (AFI) de 12 cm en la ecografía?",
      "¿Cómo tomar adecuadamente el hierro y el calcio?",
      "Recomendaciones nutricionales en el posparto",
      "El bebé lleva 2 días sin hacer deposición, ¿es normal?"
    ]
  },
  common: {
    save: "Guardar",
    cancel: "Cancelar",
    delete: "Eliminar",
    view: "Ver",
    edit: "Editar",
    normal: "Normal",
    attention: "Consultar Médico",
    date: "Fecha",
    time: "Hora",
    notes: "Notas",
    completed: "Completado",
    pending: "Pendiente",
  }
};

const FR_TRANSLATION: TranslationSchema = {
  ...EN_TRANSLATION,
  appName: "Mumora",
  tagline: "Healthy Moms ♥ Brighter Tomorrows",
  nav: {
    pregnancy: "Suivi de Grossesse",
    baby: "Bébé & Croissance",
    aiAssistant: "Assistant Mumora AI",
    vault: "Dossier Médical",
    postpartum: "Post-partum & Moral",
    hospitals: "Maternités Proches",
    adminBlueprint: "Architecture Système",
  },
  emergency: {
    call108: "SAMU (15 / 112)",
    call102: "Urgences Maternité",
    title: "Guide des Urgences Obstétricales et Pédiatriques",
    subtitle: "En présence de signes d'alerte, rendez-vous immédiatement aux urgences.",
    redFlags: [
      "Saignements vaginaux ou pertes brunes",
      "Diminution ou absence de mouvements fœtaux après 24-28 semaines",
      "Céphalées intenses persistantes avec troubles visuels",
      "Œdème soudain et important du visage ou des mains",
      "Douleurs abdominales vives",
      "Fuite de liquide amniotique",
      "Fièvre élevée > 38°C ou frissons",
      "Pour le nourrisson : Fièvre, détresse respiratoire, léthargie"
    ],
    close: "Fermer",
    quickDial: "Aide Immédiate"
  },
  assistant: {
    title: "Compagnon de Santé Mumora AI",
    subtitle: "Conseils cliniques fiables en français. Ne remplace pas un médecin.",
    inputPlaceholder: "Posez votre question sur la grossesse, les échographies, l'allaitement...",
    send: "Envoyer",
    thinking: "Analyse des recommandations cliniques...",
    disclaimer: "Avis médical : Mumora AI offre des repères éducatifs et ne remplace pas une consultation médicale d'urgence.",
    quickPrompts: [
      "Combien de mouvements fœtaux doit-on compter à 28 semaines ?",
      "Que signifie un index amniotique de 14 cm ?",
      "Comment bien associer le fer et le calcium ?",
      "Conseils pour la récupération post-partum",
      "Mon nourrisson n'a pas fait de selles depuis 48h, que faire ?"
    ]
  }
};

const AR_TRANSLATION: TranslationSchema = {
  ...EN_TRANSLATION,
  appName: "Mumora (ميومورا)",
  tagline: "Healthy Moms ♥ Brighter Tomorrows",
  nav: {
    pregnancy: "متابعة الحمل",
    baby: "الطفل والنمو",
    aiAssistant: "مساعد Mumora الذكي",
    vault: "الملف الطبي والتحاليل",
    postpartum: "ما بعد الولادة",
    hospitals: "أقرب المستشفيات",
    adminBlueprint: "هندسة النظام",
  },
  emergency: {
    call108: "الاتصال بالإسعاف (997 / 112)",
    call102: "طوارئ الولادة",
    title: "دليل طوارئ الحمل والأطفال حديثي الولادة",
    subtitle: "إذا لاحظت أي علامات تحذيرية، توجهي فوراً إلى قسم طوارئ الولادة.",
    redFlags: [
      "نزيف مهبلي أو بقع دم داكنة",
      "قلة أو توقف حركة الجنين بعد الأسبوع 24-28",
      "صداع شديد ومستمر مع تشوش في الرؤية",
      "تورم مفاجئ في الوجه أو اليدين أو الكاحلين",
      "ألم شديد في الجزء العلوي من البطن",
      "تسرب السائل الأمينوسي (نزول ماء الرأس)",
      "حمى شديدة أعلى من 38 درجة مئوية",
      "للطفل: حمى، صعوبة في التنفس، شحوب أو ازرقاق الشفاه"
    ],
    close: "إغلاق",
    quickDial: "مساعدة عاجلة"
  },
  pregnancy: {
    ...EN_TRANSLATION.pregnancy,
    weekTitle: "أسبوع الحمل",
    trimester: "الثلث",
    daysToGo: "أيام متبقية",
    dueDate: "تاريخ الولادة المتوقع",
    babySize: "حجم الجنين يماثل",
    length: "الطول",
    weight: "الوزن",
    vitalLogs: "العلامات الحيوية للأم",
    kickCounter: "حاسبة ركلات الجنين",
    contractionTimer: "مؤقت انقباضات الولادة",
    hospitalBag: "حقيبة المستشفى",
  },
  assistant: {
    title: "مساعد Mumora لصحة الأم والطفل",
    subtitle: "إرشادات طبية دقيقة باللغة العربية. ليس بديلاً عن الطبيب المختص.",
    inputPlaceholder: "اسألي عن مراحل الحمل، نتائج السونار، تغذية الأم أو رعاية الرضيع...",
    send: "إرسال",
    thinking: "جاري تحليل الإرشادات السريرية...",
    disclaimer: "تنبيه أمان طبي: يقدم Mumora AI دليلاً تعليمياً ولا يحل محل التشخيص الطبي أو وصفات الطبيب.",
    quickPrompts: [
      "كم عدد ركلات الجنين الطبيعية في الأسبوع 28؟",
      "ما معنى مؤشر السائل الأمنيوسي 12 سم في السونار؟",
      "ما هي الطريقة الصحيحة لتناول مكملات الحديد والكالسيوم؟",
      "نصائح التغذية والراحة بعد الولادة الطبيعية والقيصرية",
      "طفلي الرضيع لم يتبرز منذ يومين، هل هذا طبيعي؟"
    ]
  },
  common: {
    save: "حفظ",
    cancel: "إلغاء",
    delete: "حذف",
    view: "عرض",
    edit: "تعديل",
    normal: "طبيعي",
    attention: "مراجعة الطبيب",
    date: "التاريخ",
    time: "الوقت",
    notes: "ملاحظات",
    completed: "مكتمل",
    pending: "قيد الانتظار",
  }
};

const BN_TRANSLATION: TranslationSchema = {
  ...EN_TRANSLATION,
  appName: "Mumora (মিউমোরা)",
  tagline: "Healthy Moms ♥ Brighter Tomorrows",
  nav: {
    pregnancy: "গর্ভাবস্থা ট্র্যাকার",
    baby: "শিশু ও বৃদ্ধি",
    aiAssistant: "Mumora AI চ্যাট",
    vault: "মেডিকেল রিপোর্ট",
    postpartum: "প্রসবোত্তর যত্ন",
    hospitals: "নিকটস্থ হাসপাতাল",
    adminBlueprint: "সিস্টেম ব্লুপ্রিন্ট",
  },
  emergency: {
    call108: "১০৮ এ কল করুন (অ্যাম্বুলেন্স)",
    call102: "১০২ জননী এক্সপ্রেস",
    title: "জরুরি সতর্কবার্তা ও নির্দেশিকা",
    subtitle: "কোনো বিপদচিহ্ন দেখা দিলে অবিলম্বে প্রসূতি হাসপাতালে যান।",
    redFlags: [
      "যোনিপথে রক্তপাত বা বাদামি দাগ",
      "২৪-২৮ সপ্তাহের পর গর্ভস্থ শিশুর নড়াচড়া কমে যাওয়া বা বন্ধ হওয়া",
      "তীব্র অবিরাম মাথাব্যথা ও চোখে ঝাপসা দেখা",
      "মুখ, হাত বা পায়ে হঠাৎ অতিরিক্ত ফোলাভাব",
      "পেটের উপরের অংশে তীব্র অসহ্য যন্ত্রণা",
      "যোনিপথ দিয়ে জল ভাঙা (Water Breaking)",
      "তীব্র জ্বর (> ৩৮°C / ১০০.৪°F) বা কাঁপুনি",
      "শিশুর জন্য: তীব্র জ্বর, শ্বাসকষ্ট, নীলচে ঠোঁট"
    ],
    close: "বন্ধ করুন",
    quickDial: "জরুরি সহায়তা"
  },
  pregnancy: {
    ...EN_TRANSLATION.pregnancy,
    weekTitle: "গর্ভাবস্থার সপ্তাহ",
    trimester: "ত্রৈমাসিক",
    daysToGo: "দিন বাকি",
    dueDate: "প্রসবের সম্ভাব্য তারিখ (EDD)",
    babySize: "শিশুটির আকার এখন",
    length: "দৈর্ঘ্য",
    weight: "ওজন",
    vitalLogs: "মায়ের স্বাস্থ্যের মাপজোখ",
    kickCounter: "কিক কাউন্টার",
    contractionTimer: "প্রসব বেদনার টাইমার",
    hospitalBag: "হাসপাতাল ব্যাগের প্রস্তুতি",
  },
  assistant: {
    title: "Mumora AI স্বাস্থ্য সহযোগী",
    subtitle: "ক্লিনিক্যাল নির্দেশিকা ভিত্তিক তথ্য। ডাক্তারের বিকল্প নয়।",
    inputPlaceholder: "গর্ভাবস্থা, আল্ট্রাসাউন্ড রিপোর্ট বা শিশুর যত্ন সম্পর্কে প্রশ্ন করুন...",
    send: "পাঠান",
    thinking: "পরামর্শ প্রস্তুত করা হচ্ছে...",
    disclaimer: "মেডিকেল নোটিশ: Mumora AI কেবল শিক্ষামূলক তথ্য দেয়। কোনো জরুরি প্রয়োজনে অবিলম্বে ডাক্তারের সাথে যোগাযোগ করুন।",
    quickPrompts: [
      "২৮ সপ্তাহে শিশুর নড়াচড়া কতবার হওয়া স্বাভাবিক?",
      "আল্ট্রাসাউন্ডে AFI ১২ সেমি বলতে কী বোঝায়?",
      "আয়রন ও ক্যালসিয়াম ওষুধ খাওয়ার সঠিক নিয়ম কী?",
      "ডেলিভারির পর মায়ের পুষ্টিকর খাবার ও যত্ন",
      "বাচ্চা ২ দিন ধরে পটি করেনি, এটি কি স্বাভাবিক?"
    ]
  }
};

const SW_TRANSLATION: TranslationSchema = {
  ...EN_TRANSLATION,
  appName: "Mumora",
  tagline: "Healthy Moms ♥ Brighter Tomorrows",
  nav: {
    pregnancy: "Ufuatiliaji wa Ujauzito",
    baby: "Mtoto na Ukuaji",
    aiAssistant: "Msaidizi wa Mumora AI",
    vault: "Kumbukumbu za Matibabu",
    postpartum: "Uzazi na Hisia",
    hospitals: "Hospitali za Karibu",
    adminBlueprint: "Ramani ya Mfumo",
  },
  emergency: {
    call108: "Piga Simu ya Dharura (112 / 999)",
    call102: "Gari la Wagonjwa la Wazazi",
    title: "Miongozo ya Dharura ya Uzazi na Watoto",
    subtitle: "Ukiona dalili zozote za hatari, fika mara moja hospitalini.",
    redFlags: [
      "Kutoka damu ukeni",
      "Kupungua au kukoma kwa mienendo ya mtoto tumboni baada ya wiki 24-28",
      "Kuumwa sana na kichwa kusikoisha na kutoona vizuri",
      "Kuvimba ghafla uso, mikono, au miguu",
      "Maumivu makali ya tumbo",
      "Kuvuja maji ukeni kabla ya wakati",
      "Homa kali (> 38°C) au kutetemeka",
      "Kwa mtoto: Homa kali, kupumua kwa shida, midomo kuwa ya buluu"
    ],
    close: "Funga",
    quickDial: "Msaada wa Haraka"
  },
  assistant: {
    title: "Msaidizi wa Afya wa Mumora AI",
    subtitle: "Mwongozo wa kliniki kwa lugha ya Kiswahili. Sio mbadala wa daktari.",
    inputPlaceholder: "Uliza kuhusu wiki yako ya ujauzito, vipimo, au afya ya mtoto...",
    send: "Tuma",
    thinking: "Inachambua miongozo ya afya...",
    disclaimer: "Ilani ya Matibabu: Mumora AI inatoa elimu ya afya. Tafadhali wasiliana na daktari kwa maamuzi ya kitabibu.",
    quickPrompts: [
      "Je, mtoto anapaswa kupiga teke mara ngapi katika wiki ya 28?",
      "Kipimo cha maji ya uzazi (AFI) 12 cm kina maana gani?",
      "Jinsi ya kutumia vidonge vya madini ya chuma na kalisi kwa usahihi?",
      "Lishe bora na malezi baada ya kujifungua",
      "Mtoto hajaenda haja kubwa kwa siku 2, je ni kawaida?"
    ]
  }
};

const ZH_TRANSLATION: TranslationSchema = {
  ...EN_TRANSLATION,
  appName: "Mumora (孕宝健康)",
  tagline: "Healthy Moms ♥ Brighter Tomorrows",
  nav: {
    pregnancy: "孕期追踪",
    baby: "宝宝与成长",
    aiAssistant: "Mumora AI 助手",
    vault: "医疗报告档案",
    postpartum: "产后康复与情绪",
    hospitals: "附近妇幼医院",
    adminBlueprint: "系统技术蓝图",
  },
  emergency: {
    call108: "拨打急救电话 (120)",
    call102: "妇幼急救专线",
    title: "产科与新生儿急诊警报指南",
    subtitle: "如出现危险体征，请立即前往最近的医院产科急诊。",
    redFlags: [
      "阴道出血或褐色分泌物",
      "孕24-28周后胎动明显减少或停止",
      "持续剧烈头痛伴视力模糊或闪光感",
      "面部、手部或踝部突发严重水肿",
      "剧烈腹痛或右上腹剧痛",
      "阴道流液（胎膜早破/破水）",
      "高热超过 38°C 或严重寒战",
      "新生儿：高烧、呼吸窘迫、呻吟、口唇发绀"
    ],
    close: "关闭",
    quickDial: "紧急求助"
  },
  pregnancy: {
    ...EN_TRANSLATION.pregnancy,
    weekTitle: "当前孕周",
    trimester: "孕期阶段",
    daysToGo: "天倒计时",
    dueDate: "预产期 (EDD)",
    babySize: "宝宝现在相当于",
    length: "身长",
    weight: "体重",
    vitalLogs: "孕妈生命体征",
    kickCounter: "胎动计数器",
    contractionTimer: "宫缩计时器",
    hospitalBag: "待产包清单",
  },
  assistant: {
    title: "Mumora AI 母婴健康顾问",
    subtitle: "基于全球权威临床指南的专业支持。不能替代医生面诊。",
    inputPlaceholder: "输入关于孕周发展、B超指标、母乳喂养或新生儿护理的问题...",
    send: "发送",
    thinking: "正在检索临床指南...",
    disclaimer: "医疗安全警示：Mumora AI 仅提供健康科普与指导，不具备处方权或最终医学诊断功能。",
    quickPrompts: [
      "孕28周后每天胎动应该记录几次？",
      "B超单上的羊水指数 AFI 12 cm 属于正常范围吗？",
      "补铁剂和钙片应该如何间隔时间服用？",
      "产后坐月子与母乳喂养的科学营养建议",
      "新生儿两天未排便是否需要就医？"
    ]
  }
};

const BASE_DICTIONARY: Record<string, Partial<TranslationSchema>> = {
  en: EN_TRANSLATION,
  hi: HI_TRANSLATION,
  es: ES_TRANSLATION,
  fr: FR_TRANSLATION,
  ar: AR_TRANSLATION,
  bn: BN_TRANSLATION,
  sw: SW_TRANSLATION,
  zh: ZH_TRANSLATION,
};

// Safe Proxy translation retriever to ensure zero missing keys across all 45+ languages
export function getTranslation(lang: string): TranslationSchema {
  const selected = BASE_DICTIONARY[lang] || {};
  return {
    ...EN_TRANSLATION,
    ...selected,
    nav: { ...EN_TRANSLATION.nav, ...(selected.nav || {}) },
    emergency: { ...EN_TRANSLATION.emergency, ...(selected.emergency || {}) },
    pregnancy: { ...EN_TRANSLATION.pregnancy, ...(selected.pregnancy || {}) },
    baby: { ...EN_TRANSLATION.baby, ...(selected.baby || {}) },
    assistant: { ...EN_TRANSLATION.assistant, ...(selected.assistant || {}) },
    records: { ...EN_TRANSLATION.records, ...(selected.records || {}) },
    postpartum: { ...EN_TRANSLATION.postpartum, ...(selected.postpartum || {}) },
    common: { ...EN_TRANSLATION.common, ...(selected.common || {}) },
  };
}

// Proxied TRANSLATIONS mapping for seamless backwards compatibility
export const TRANSLATIONS: Record<string, TranslationSchema> = new Proxy(
  BASE_DICTIONARY as any,
  {
    get: (_target, prop: string) => {
      return getTranslation(prop);
    },
  }
);

export const INITIAL_HOSPITAL_BAG_ITEMS = [
  { id: 'hb_1', category: 'mother' as const, item: 'Comfortable front-open feeding nighties / Kurtas (3-4 pairs)', itemHi: 'स्तनपान के अनुकूल फ्रंट-ओपन नाइटी या कुर्ते (3-4 जोड़ी)', isPacked: true, quantity: '3-4' },
  { id: 'hb_2', category: 'mother' as const, item: 'Maternity sanitary pads (extra absorbent, 2 packs)', itemHi: 'मैटरनिटी सेनेटरी पैड्स (अतिरिक्त सोखने वाले, 2 पैकेट)', isPacked: true, quantity: '2 packs' },
  { id: 'hb_3', category: 'mother' as const, item: 'Nursing bras and breast pads', itemHi: 'नर्सिंग ब्रा और ब्रेस्ट पैड्स', isPacked: false, quantity: '3' },
  { id: 'hb_4', category: 'mother' as const, item: 'Warm socks, slippers, and shawl/cardigan', itemHi: 'गर्म मोजे, चप्पल और शॉल / कार्डिगन', isPacked: true, quantity: '2 pairs' },
  { id: 'hb_5', category: 'mother' as const, item: 'Toiletries: Toothbrush, soap, lip balm, hair ties', itemHi: 'टूथब्रश, साबुन, लिप बाम, बालों की रबरबैंड', isPacked: true, quantity: '1 kit' },
  { id: 'hb_6', category: 'baby' as const, item: 'Soft washed cotton baby clothes (Jhablas) & swaddle cloths', itemHi: 'मुलायम सूती बच्चे के कपड़े (झबले) और लपेटने के कपड़े', isPacked: true, quantity: '5-6 sets' },
  { id: 'hb_7', category: 'baby' as const, item: 'Newborn diapers and water-based baby wipes', itemHi: 'नवजात डायपर और वाटर-बेस्ड बेबी वाइप्स', isPacked: false, quantity: '1 pack' },
  { id: 'hb_8', category: 'baby' as const, item: 'Baby caps, mittens, and socks booties', itemHi: 'बच्चे की टोपी, दस्ताने और मोज़े', isPacked: true, quantity: '3 pairs' },
  { id: 'hb_9', category: 'baby' as const, item: 'Soft baby blanket for discharge home', itemHi: 'घर लाते समय बच्चे के लिए मुलायम कंबल', isPacked: false, quantity: '1' },
  { id: 'hb_10', category: 'documents' as const, item: 'Complete antenatal file: All ultrasound scans & blood reports', itemHi: 'पूरी एंटीनेटल फाइल: सभी सोनोग्राफी और ब्लड रिपोर्ट्स', isPacked: true, quantity: 'Originals' },
  { id: 'hb_11', category: 'documents' as const, item: 'Mother & Partner Aadhaar Card & Government IDs', itemHi: 'माता और पिता का आधार कार्ड एवं सरकारी पहचान पत्र', isPacked: true, quantity: 'Copies + Orig' },
  { id: 'hb_12', category: 'documents' as const, item: 'Health Insurance TPA Card & Pre-authorization letters', itemHi: 'स्वास्थ्य बीमा (Health Insurance) कार्ड और दस्तावेज', isPacked: true, quantity: '1 file' },
  { id: 'hb_13', category: 'partner' as const, item: 'Phone chargers with extra long cables and power bank', itemHi: 'फोन चार्जर और पावर बैंक', isPacked: true, quantity: '2' },
  { id: 'hb_14', category: 'partner' as const, item: 'Healthy snacks: Dry fruits, nuts, roasted makhana, biscuits', itemHi: 'पौष्टिक नाश्ता: मेवे, भुना मखाना, बिस्कुट', isPacked: false, quantity: '1 box' },
  { id: 'hb_15', category: 'partner' as const, item: 'Small cash and digital payment ready on phone', itemHi: 'छुट्टा नकद और फोन पर यूपीआई डिजिटल पेमेंट', isPacked: true, quantity: '₹3000-5000' },
  { id: 'hb_16', category: 'documents' as const, item: 'Newborn Vaccine Card & BCG Birth Immunization Checklist', itemHi: 'नवजात शिशु टीकाकरण कार्ड एवं बीसीजी जन्म टीका चेकलिस्ट', isPacked: true, quantity: '1 card' },
];

export const EPDS_QUESTIONS = [
  {
    id: 1,
    question: "I have been able to laugh and see the funny side of things:",
    questionHi: "मैं हंसने और बातों के सुखद पहलू को देखने में सक्षम रही हूँ:",
    options: [
      { text: "As much as I always could", textHi: "हमेशा की तरह पूरी तरह", score: 0 },
      { text: "Not quite so much now", textHi: "अब पहले जितना नहीं", score: 1 },
      { text: "Definitely not so much now", textHi: "निश्चित रूप से अब बहुत कम", score: 2 },
      { text: "Not at all", textHi: "बिल्कुल नहीं", score: 3 },
    ]
  },
  {
    id: 2,
    question: "I have looked forward with enjoyment to things:",
    questionHi: "मैं आने वाली चीजों का खुशी से इंतजार करती रही हूँ:",
    options: [
      { text: "As much as I ever did", textHi: "हमेशा की तरह उमंग से", score: 0 },
      { text: "Rather less than I used to", textHi: "पहले की तुलना में कुछ कम", score: 1 },
      { text: "Definitely less than I used to", textHi: "पहले से काफी कम", score: 2 },
      { text: "Hardly at all", textHi: "शायद ही कभी", score: 3 },
    ]
  },
  {
    id: 3,
    question: "I have blamed myself unnecessarily when things went wrong:",
    questionHi: "चीजें गलत होने पर मैंने बेवजह खुद को दोषी ठहराया है:",
    options: [
      { text: "Yes, most of the time", textHi: "हाँ, ज्यादातर समय", score: 3 },
      { text: "Yes, some of the time", textHi: "हाँ, कभी-कभी", score: 2 },
      { text: "Not very often", textHi: "बहुत कम बार", score: 1 },
      { text: "No, never", textHi: "नहीं, कभी नहीं", score: 0 },
    ]
  },
  {
    id: 4,
    question: "I have been anxious or worried for no good reason:",
    questionHi: "मैं बिना किसी ठोस वजह के चिंतित या घबराई हुई रही हूँ:",
    options: [
      { text: "No, not at all", textHi: "नहीं, बिल्कुल नहीं", score: 0 },
      { text: "Hardly ever", textHi: "शायद ही कभी", score: 1 },
      { text: "Yes, sometimes", textHi: "हाँ, कभी-कभी", score: 2 },
      { text: "Yes, very often", textHi: "हाँ, बहुत अधिक बार", score: 3 },
    ]
  },
  {
    id: 5,
    question: "I have felt scared or panicky for no very good reason:",
    questionHi: "मुझे बिना किसी खास वजह के डर या पैनिक महसूस हुआ है:",
    options: [
      { text: "Yes, quite a lot", textHi: "हाँ, काफी ज्यादा", score: 3 },
      { text: "Yes, sometimes", textHi: "हाँ, कभी-कभी", score: 2 },
      { text: "No, not much", textHi: "नहीं, ज्यादा नहीं", score: 1 },
      { text: "No, not at all", textHi: "नहीं, बिल्कुल नहीं", score: 0 },
    ]
  },
  {
    id: 6,
    question: "Things have been getting on top of me (feeling overwhelmed):",
    questionHi: "जिम्मेदारियां मुझ पर हावी हो रही हैं (थकावट और लाचारी महसूस होना):",
    options: [
      { text: "Yes, most of the time I haven't been able to cope", textHi: "हाँ, ज्यादातर समय मैं संभाल नहीं पा रही हूँ", score: 3 },
      { text: "Yes, sometimes I haven't been coping as well as usual", textHi: "हाँ, कभी-कभी पहले जैसा नहीं संभाल पाती", score: 2 },
      { text: "No, most of the time I have coped quite well", textHi: "नहीं, ज्यादातर समय अच्छी तरह संभाल रही हूँ", score: 1 },
      { text: "No, I have been coping as well as ever", textHi: "नहीं, हमेशा की तरह पूरी तरह सक्षम हूँ", score: 0 },
    ]
  },
  {
    id: 7,
    question: "I have been so unhappy that I have had difficulty sleeping:",
    questionHi: "मैं इतनी दुखी रही हूँ कि मुझे सोने में परेशानी हुई है:",
    options: [
      { text: "Yes, most of the time", textHi: "हाँ, अधिकतर समय", score: 3 },
      { text: "Yes, sometimes", textHi: "हाँ, कभी-कभी", score: 2 },
      { text: "Not very often", textHi: "बहुत कम बार", score: 1 },
      { text: "No, not at all", textHi: "नहीं, बिल्कुल नहीं", score: 0 },
    ]
  },
  {
    id: 8,
    question: "I have felt sad or miserable:",
    questionHi: "मैंने उदास या बेबस महसूस किया है:",
    options: [
      { text: "Yes, most of the time", textHi: "हाँ, ज्यादातर समय", score: 3 },
      { text: "Yes, quite often", textHi: "हाँ, काफी बार", score: 2 },
      { text: "Not very often", textHi: "कभी-कभार ही", score: 1 },
      { text: "No, not at all", textHi: "नहीं, बिल्कुल नहीं", score: 0 },
    ]
  },
  {
    id: 9,
    question: "I have been so unhappy that I have been crying:",
    questionHi: "मैं इतनी परेशान रही हूँ कि रोने लगी हूँ:",
    options: [
      { text: "Yes, most of the time", textHi: "हाँ, लगभग रोज", score: 3 },
      { text: "Yes, quite often", textHi: "हाँ, अक्सर", score: 2 },
      { text: "Only occasionally", textHi: "केवल कभी-कभार", score: 1 },
      { text: "No, never", textHi: "नहीं, कभी नहीं", score: 0 },
    ]
  },
  {
    id: 10,
    question: "The thought of harming myself has occurred to me:",
    questionHi: "खुद को नुकसान पहुंचाने का विचार मेरे मन में आया है:",
    options: [
      { text: "Yes, quite often", textHi: "हाँ, अक्सर", score: 3 },
      { text: "Sometimes", textHi: "कभी-कभी", score: 2 },
      { text: "Hardly ever", textHi: "शायद ही कभी", score: 1 },
      { text: "Never", textHi: "कभी नहीं", score: 0 },
    ]
  }
];
